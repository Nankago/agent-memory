# Reader Temporal Examples

## locomo / hybrid_bge_m3_rerank / reader_llama31_8b_instruct

- query_id: `conv-26_qa0000`
  prompt: When did Caroline go to the LGBTQ support group?
  gold: `7 May 2023`
  pred: `yesterday`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"yesterday"}`

- query_id: `conv-26_qa0001`
  prompt: When did Melanie paint a sunrise?
  gold: `2022`
  pred: `last week`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"last week"}`

- query_id: `conv-26_qa0005`
  prompt: When did Melanie run a charity race?
  gold: `The sunday before 25 May 2023`
  pred: `last Saturday`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"last Saturday"}`

- query_id: `conv-26_qa0006`
  prompt: When is Melanie planning on going camping?
  gold: `June 2023`
  pred: `a few weeks ago`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"a few weeks ago"}`

- query_id: `conv-26_qa0008`
  prompt: When did Caroline give a speech at a school?
  gold: `The week before 9 June 2023`
  pred: `last week`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer": "last week"}`

- query_id: `conv-26_qa0016`
  prompt: When did Melanie sign up for a pottery class?
  gold: `2 July 2023`
  pred: `yesterday`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"yesterday"}`

- query_id: `conv-26_qa0017`
  prompt: When is Caroline going to the transgender conference?
  gold: `July 2023`
  pred: `two days ago`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"two days ago"}`

- query_id: `conv-26_qa0020`
  prompt: When did Melanie go to the museum?
  gold: `5 July 2023`
  pred: `Yesterday`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"Yesterday"}`

## locomo / hybrid_bge_m3_rerank / reader_qwen25_14b_instruct

- query_id: `conv-26_qa0000`
  prompt: When did Caroline go to the LGBTQ support group?
  gold: `7 May 2023`
  pred: `yesterday`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"yesterday"}`

- query_id: `conv-26_qa0001`
  prompt: When did Melanie paint a sunrise?
  gold: `2022`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0005`
  prompt: When did Melanie run a charity race?
  gold: `The sunday before 25 May 2023`
  pred: `last Saturday`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"last Saturday"}`

- query_id: `conv-26_qa0006`
  prompt: When is Melanie planning on going camping?
  gold: `June 2023`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0008`
  prompt: When did Caroline give a speech at a school?
  gold: `The week before 9 June 2023`
  pred: `last week`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"last week"}`

- query_id: `conv-26_qa0016`
  prompt: When did Melanie sign up for a pottery class?
  gold: `2 July 2023`
  pred: `yesterday`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"yesterday"}`

- query_id: `conv-26_qa0017`
  prompt: When is Caroline going to the transgender conference?
  gold: `July 2023`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0020`
  prompt: When did Melanie go to the museum?
  gold: `5 July 2023`
  pred: `Yesterday`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"Yesterday"}`

## locomo / hybrid_bge_m3_rerank / reader_qwen25_7b_instruct

- query_id: `conv-26_qa0000`
  prompt: When did Caroline go to the LGBTQ support group?
  gold: `7 May 2023`
  pred: `yesterday`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"yesterday"}`

- query_id: `conv-26_qa0001`
  prompt: When did Melanie paint a sunrise?
  gold: `2022`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0005`
  prompt: When did Melanie run a charity race?
  gold: `The sunday before 25 May 2023`
  pred: `last Saturday`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"last Saturday"}`

- query_id: `conv-26_qa0006`
  prompt: When is Melanie planning on going camping?
  gold: `June 2023`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0008`
  prompt: When did Caroline give a speech at a school?
  gold: `The week before 9 June 2023`
  pred: `last week`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"last week"}`

- query_id: `conv-26_qa0016`
  prompt: When did Melanie sign up for a pottery class?
  gold: `2 July 2023`
  pred: `yesterday`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"yesterday"}`

- query_id: `conv-26_qa0017`
  prompt: When is Caroline going to the transgender conference?
  gold: `July 2023`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0020`
  prompt: When did Melanie go to the museum?
  gold: `5 July 2023`
  pred: `Yesterday`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"Yesterday"}`

## longmemeval / hybrid_bge_m3_rerank / reader_llama31_8b_instruct

- query_id: `58ef2f1c`
  prompt: When did I volunteer at the local animal shelter's fundraising dinner?
  gold: `February 14th`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `c19f7a0b`
  prompt: What time do I usually get home from work on weeknights?
  gold: `6:30 pm`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `time_of_day` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `51c32626`
  prompt: When did I submit my research paper on sentiment analysis?
  gold: `February 1st`
  pred: `research paper on sentiment analysis`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"before that, I even worked on a research paper on sentiment analysis, which I submitted to ACL."}`

- query_id: `73d42213`
  prompt: What time did I reach the clinic on Monday?
  gold: `9:00 AM`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `time_of_day` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `gpt4_2c50253f`
  prompt: What time do I wake up on Tuesdays and Thursdays?
  gold: `6:45 AM`
  pred: `15 minutes earlier`
  correct: `False`, exact: `False`
  bucket: `time_of_day` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer": "15 minutes earlier"}`

- query_id: `982b5123_abs`
  prompt: When did I book the Airbnb in Sacramento?
  gold: `The information provided is not enough. You only mentioned booking Airbnb in San Francisco.`
  pred: `three months in advance`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer": "three months in advance"}`

- query_id: `59524333`
  prompt: What time do I usually go to the gym?
  gold: `6:00 pm`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `time_of_day` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `dad224aa`
  prompt: What time do I wake up on Saturday mornings?
  gold: `7:30 am`
  pred: `30 am`
  correct: `False`, exact: `False`
  bucket: `time_of_day` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"7:30 am"}`

## longmemeval / hybrid_bge_m3_rerank / reader_qwen25_14b_instruct

- query_id: `58ef2f1c`
  prompt: When did I volunteer at the local animal shelter's fundraising dinner?
  gold: `February 14th`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `c19f7a0b`
  prompt: What time do I usually get home from work on weeknights?
  gold: `6:30 pm`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `time_of_day` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `51c32626`
  prompt: When did I submit my research paper on sentiment analysis?
  gold: `February 1st`
  pred: `before completing the master's thesis`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"before completing the master's thesis"}`

- query_id: `73d42213`
  prompt: What time did I reach the clinic on Monday?
  gold: `9:00 AM`
  pred: `two hours`
  correct: `False`, exact: `False`
  bucket: `time_of_day` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"two hours"}`

- query_id: `gpt4_2c50253f`
  prompt: What time do I wake up on Tuesdays and Thursdays?
  gold: `6:45 AM`
  pred: `00 AM`
  correct: `False`, exact: `False`
  bucket: `time_of_day` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"7:00 AM"}`

- query_id: `982b5123_abs`
  prompt: When did I book the Airbnb in Sacramento?
  gold: `The information provided is not enough. You only mentioned booking Airbnb in San Francisco.`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `59524333`
  prompt: What time do I usually go to the gym?
  gold: `6:00 pm`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `time_of_day` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `dad224aa`
  prompt: What time do I wake up on Saturday mornings?
  gold: `7:30 am`
  pred: `30 am`
  correct: `False`, exact: `False`
  bucket: `time_of_day` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"7:30 am"}`

## longmemeval / hybrid_bge_m3_rerank / reader_qwen25_7b_instruct

- query_id: `58ef2f1c`
  prompt: When did I volunteer at the local animal shelter's fundraising dinner?
  gold: `February 14th`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `c19f7a0b`
  prompt: What time do I usually get home from work on weeknights?
  gold: `6:30 pm`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `time_of_day` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `51c32626`
  prompt: When did I submit my research paper on sentiment analysis?
  gold: `February 1st`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `73d42213`
  prompt: What time did I reach the clinic on Monday?
  gold: `9:00 AM`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `time_of_day` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `gpt4_2c50253f`
  prompt: What time do I wake up on Tuesdays and Thursdays?
  gold: `6:45 AM`
  pred: `00 AM`
  correct: `False`, exact: `False`
  bucket: `time_of_day` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"7:00 AM"}`

- query_id: `982b5123_abs`
  prompt: When did I book the Airbnb in Sacramento?
  gold: `The information provided is not enough. You only mentioned booking Airbnb in San Francisco.`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `59524333`
  prompt: What time do I usually go to the gym?
  gold: `6:00 pm`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `time_of_day` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `dad224aa`
  prompt: What time do I wake up on Saturday mornings?
  gold: `7:30 am`
  pred: `30 am`
  correct: `False`, exact: `False`
  bucket: `time_of_day` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"7:30 am"}`
