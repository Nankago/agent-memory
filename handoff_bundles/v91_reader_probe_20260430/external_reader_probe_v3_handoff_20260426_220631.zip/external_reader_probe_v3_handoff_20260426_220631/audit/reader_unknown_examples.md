# Reader Unknown Examples

## locomo / hybrid_bge_m3_rerank / reader_llama31_8b_instruct

- query_id: `conv-26_qa0010`
  prompt: How long has Caroline had her current group of friends for?
  gold: `4 years`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `conv-26_qa0021`
  prompt: When did Caroline have a picnic?
  gold: `The week before 6 July 2023`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `conv-26_qa0023`
  prompt: What books has Melanie read?
  gold: `"Nothing is Impossible", "Charlotte's Web"`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `title_or_name` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `conv-26_qa0026`
  prompt: When did Melanie read the book "nothing is impossible"?
  gold: `2022`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `conv-26_qa0054`
  prompt: When did Caroline draw a self-portrait?
  gold: `The week before 23 August 2023`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `conv-26_qa0063`
  prompt: When is Caroline's youth center putting on a talent show?
  gold: `September 2023`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `conv-26_qa0071`
  prompt: What book did Melanie read from Caroline's suggestion?
  gold: `"Becoming Nicole"`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `title_or_name` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `conv-26_qa0076`
  prompt: When did Melanie go on a hike after the roadtrip?
  gold: `19 October 2023`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

## locomo / hybrid_bge_m3_rerank / reader_qwen25_14b_instruct

- query_id: `conv-26_qa0001`
  prompt: When did Melanie paint a sunrise?
  gold: `2022`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0006`
  prompt: When is Melanie planning on going camping?
  gold: `June 2023`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0010`
  prompt: How long has Caroline had her current group of friends for?
  gold: `4 years`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0011`
  prompt: Where did Caroline move from 4 years ago?
  gold: `Sweden`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `where` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0017`
  prompt: When is Caroline going to the transgender conference?
  gold: `July 2023`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0021`
  prompt: When did Caroline have a picnic?
  gold: `The week before 6 July 2023`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0022`
  prompt: Would Caroline likely have Dr. Seuss books on her bookshelf?
  gold: `Yes, since she collects classic children's books`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `judgment` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0023`
  prompt: What books has Melanie read?
  gold: `"Nothing is Impossible", "Charlotte's Web"`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `title_or_name` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

## locomo / hybrid_bge_m3_rerank / reader_qwen25_7b_instruct

- query_id: `conv-26_qa0001`
  prompt: When did Melanie paint a sunrise?
  gold: `2022`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0006`
  prompt: When is Melanie planning on going camping?
  gold: `June 2023`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0010`
  prompt: How long has Caroline had her current group of friends for?
  gold: `4 years`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0011`
  prompt: Where did Caroline move from 4 years ago?
  gold: `Sweden`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `where` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0017`
  prompt: When is Caroline going to the transgender conference?
  gold: `July 2023`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0021`
  prompt: When did Caroline have a picnic?
  gold: `The week before 6 July 2023`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0022`
  prompt: Would Caroline likely have Dr. Seuss books on her bookshelf?
  gold: `Yes, since she collects classic children's books`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `judgment` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0023`
  prompt: What books has Melanie read?
  gold: `"Nothing is Impossible", "Charlotte's Web"`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `title_or_name` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

## longmemeval / hybrid_bge_m3_rerank / reader_llama31_8b_instruct

- query_id: `e47becba`
  prompt: What degree did I graduate with?
  gold: `Business Administration`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `degree` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `51a45a95`
  prompt: Where did I redeem a $5 coupon on coffee creamer?
  gold: `Target`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `where` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `58bf7951`
  prompt: What play did I attend at the local community theater?
  gold: `The Glass Menagerie`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `title_or_name` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `1e043500`
  prompt: What is the name of the playlist I created on Spotify?
  gold: `Summer Vibes`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `title_or_name` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `6f9b354f`
  prompt: What color did I repaint my bedroom walls?
  gold: `a lighter shade of gray`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `color` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `58ef2f1c`
  prompt: When did I volunteer at the local animal shelter's fundraising dinner?
  gold: `February 14th`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `f8c5f88b`
  prompt: Where did I buy my new tennis racket from?
  gold: `the sports store downtown`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `where` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `7527f7e2`
  prompt: How much did I spend on a designer handbag?
  gold: `$800`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `price` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

## longmemeval / hybrid_bge_m3_rerank / reader_qwen25_14b_instruct

- query_id: `e47becba`
  prompt: What degree did I graduate with?
  gold: `Business Administration`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `degree` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `118b2229`
  prompt: How long is my daily commute to work?
  gold: `45 minutes each way`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `51a45a95`
  prompt: Where did I redeem a $5 coupon on coffee creamer?
  gold: `Target`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `where` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `58bf7951`
  prompt: What play did I attend at the local community theater?
  gold: `The Glass Menagerie`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `title_or_name` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `1e043500`
  prompt: What is the name of the playlist I created on Spotify?
  gold: `Summer Vibes`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `title_or_name` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `6f9b354f`
  prompt: What color did I repaint my bedroom walls?
  gold: `a lighter shade of gray`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `color` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `58ef2f1c`
  prompt: When did I volunteer at the local animal shelter's fundraising dinner?
  gold: `February 14th`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `f8c5f88b`
  prompt: Where did I buy my new tennis racket from?
  gold: `the sports store downtown`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `where` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

## longmemeval / hybrid_bge_m3_rerank / reader_qwen25_7b_instruct

- query_id: `e47becba`
  prompt: What degree did I graduate with?
  gold: `Business Administration`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `degree` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `118b2229`
  prompt: How long is my daily commute to work?
  gold: `45 minutes each way`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `51a45a95`
  prompt: Where did I redeem a $5 coupon on coffee creamer?
  gold: `Target`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `where` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `58bf7951`
  prompt: What play did I attend at the local community theater?
  gold: `The Glass Menagerie`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `title_or_name` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `1e043500`
  prompt: What is the name of the playlist I created on Spotify?
  gold: `Summer Vibes`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `title_or_name` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `6f9b354f`
  prompt: What color did I repaint my bedroom walls?
  gold: `a lighter shade of gray`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `color` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `58ef2f1c`
  prompt: When did I volunteer at the local animal shelter's fundraising dinner?
  gold: `February 14th`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `when` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `f8c5f88b`
  prompt: Where did I buy my new tennis racket from?
  gold: `the sports store downtown`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `where` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`
