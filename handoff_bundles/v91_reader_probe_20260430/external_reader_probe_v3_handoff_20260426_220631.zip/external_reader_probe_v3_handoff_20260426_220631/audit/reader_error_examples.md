# Reader Error Examples

## locomo / hybrid_bge_m3_rerank / reader_llama31_8b_instruct

- query_id: `conv-47_qa0085`
  prompt: What breed is Daisy, one of James' dogs?
  gold: `Labrador`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `breed` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `conv-50_qa0105`
  prompt: What color glow did Calvin customize his guitar with?
  gold: `purple`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `color` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `conv-50_qa0176`
  prompt: What color glow did Dave customize his guitar with?
  gold: ``
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `color` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `conv-26_qa0010`
  prompt: How long has Caroline had her current group of friends for?
  gold: `4 years`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `conv-42_qa0208`
  prompt: For how long has Nate had his snakes?
  gold: ``
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `conv-43_qa0148`
  prompt: How long has Tim been playing the piano for, as of December 2023?
  gold: `about four months`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `conv-43_qa0225`
  prompt: How long has John been playing the piano for, as of December 2023?
  gold: ``
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `conv-49_qa0070`
  prompt: How long did Evan and his partner date before getting married?
  gold: `four months`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

## locomo / hybrid_bge_m3_rerank / reader_qwen25_14b_instruct

- query_id: `conv-26_qa0126`
  prompt: What activity did Caroline used to do with her dad?
  gold: `Horseback riding`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0180`
  prompt: What activity did Melanie used to do with her dad?
  gold: ``
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-41_qa0095`
  prompt: What activity did Maria and her mom do together in May 2023?
  gold: `Made dinner together`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-43_qa0160`
  prompt: What activity did Tim do after reading the stories about the Himalayan trek?
  gold: `visited a travel agency`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-44_qa0110`
  prompt: What activity do Andrew and Buddy enjoy doing together?
  gold: `Walking`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-44_qa0154`
  prompt: What activity do Audrey and Buddy enjoy doing together?
  gold: ``
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-48_qa0115`
  prompt: What activity does Deborah incorporate into her daily routine after going for a morning jog in the park?
  gold: `spending time with loved ones`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-48_qa0141`
  prompt: What activity does Deborah do with her cats?
  gold: `take them out for a run in the park every morning and evening`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

## locomo / hybrid_bge_m3_rerank / reader_qwen25_7b_instruct

- query_id: `conv-26_qa0126`
  prompt: What activity did Caroline used to do with her dad?
  gold: `Horseback riding`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-26_qa0180`
  prompt: What activity did Melanie used to do with her dad?
  gold: ``
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-41_qa0095`
  prompt: What activity did Maria and her mom do together in May 2023?
  gold: `Made dinner together`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-44_qa0110`
  prompt: What activity do Andrew and Buddy enjoy doing together?
  gold: `Walking`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-48_qa0141`
  prompt: What activity does Deborah do with her cats?
  gold: `take them out for a run in the park every morning and evening`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-48_qa0238`
  prompt: What activity did Jolene enjoy at the music festival with their pals on September 20, 2023?
  gold: ``
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-49_qa0060`
  prompt: Which new activity does Sam take up in October 2023?
  gold: `kayaking`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `conv-47_qa0085`
  prompt: What breed is Daisy, one of James' dogs?
  gold: `Labrador`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `breed` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

## longmemeval / hybrid_bge_m3_rerank / reader_llama31_8b_instruct

- query_id: `c14c00dd`
  prompt: What brand of shampoo do I currently use?
  gold: `Trader Joe's`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `brand` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `75499fd8`
  prompt: What breed is my dog?
  gold: `Golden Retriever`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `breed` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `6f9b354f`
  prompt: What color did I repaint my bedroom walls?
  gold: `a lighter shade of gray`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `color` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `e47becba`
  prompt: What degree did I graduate with?
  gold: `Business Administration`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `degree` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `94f70d80`
  prompt: How long did it take me to assemble the IKEA bookshelf?
  gold: `4 hours`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `001be529`
  prompt: How long did I wait for the decision on my asylum application?
  gold: `over a year`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `19b5f2b3`
  prompt: How long was I in Japan for?
  gold: `two weeks`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

- query_id: `faba32e5`
  prompt: How long did Alex marinate the BBQ ribs in special sauce?
  gold: `24 hours`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer": "unknown"}`

## longmemeval / hybrid_bge_m3_rerank / reader_qwen25_14b_instruct

- query_id: `b46e15ee`
  prompt: What charity event did I participate in a month ago?
  gold: `the 'Walk for Hunger' charity event`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `gpt4_98f46fc6`
  prompt: Which event did I participate in first, the charity gala or the charity bake sale?
  gold: `I participated in the charity bake sale first.`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `activity_list:comparative` / `comparative_reasoning`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `c8c3f81d`
  prompt: What brand are my favorite running shoes?
  gold: `Nike`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `brand` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `c14c00dd`
  prompt: What brand of shampoo do I currently use?
  gold: `Trader Joe's`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `brand` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `75499fd8`
  prompt: What breed is my dog?
  gold: `Golden Retriever`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `breed` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `6f9b354f`
  prompt: What color did I repaint my bedroom walls?
  gold: `a lighter shade of gray`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `color` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `89527b6b`
  prompt: I'm going back to our previous conversation about the children's book on dinosaurs. Can you remind me what color was the scaly body of the Plesiosaur in the image?
  gold: `The Plesiosaur had a blue scaly body.`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `color` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `e47becba`
  prompt: What degree did I graduate with?
  gold: `Business Administration`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `degree` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

## longmemeval / hybrid_bge_m3_rerank / reader_qwen25_7b_instruct

- query_id: `c8c3f81d`
  prompt: What brand are my favorite running shoes?
  gold: `Nike`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `brand` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `c14c00dd`
  prompt: What brand of shampoo do I currently use?
  gold: `Trader Joe's`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `brand` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `75499fd8`
  prompt: What breed is my dog?
  gold: `Golden Retriever`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `breed` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `6f9b354f`
  prompt: What color did I repaint my bedroom walls?
  gold: `a lighter shade of gray`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `color` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `89527b6b`
  prompt: I'm going back to our previous conversation about the children's book on dinosaurs. Can you remind me what color was the scaly body of the Plesiosaur in the image?
  gold: `The Plesiosaur had a blue scaly body.`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `color` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `e47becba`
  prompt: What degree did I graduate with?
  gold: `Business Administration`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `degree` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `118b2229`
  prompt: How long is my daily commute to work?
  gold: `45 minutes each way`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `confident_selection_error`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`

- query_id: `94f70d80`
  prompt: How long did it take me to assemble the IKEA bookshelf?
  gold: `4 hours`
  pred: `unknown`
  correct: `False`, exact: `False`
  bucket: `duration` / `supported_but_wrong`
  final_support_recall: `1.0`
  raw: `{"answer":"unknown"}`
