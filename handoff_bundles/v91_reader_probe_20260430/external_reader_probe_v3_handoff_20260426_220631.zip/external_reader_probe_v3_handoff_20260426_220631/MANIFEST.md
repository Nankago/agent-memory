# Reader Probe Handoff Manifest

Created: 2026-04-26 15:20:24 UTC

Source prediction root:
- `/gfs/space/private/wujn/Learn/agent-memory-server-bundle-v91-20260426-reader-probe-v3-qwen14/outputs/external_reader_probe_v3`

Handoff directory:
- `/gfs/space/private/wujn/Learn/agent-memory-server-bundle-v91-20260426-reader-probe-v3-qwen14/outputs/external_reader_probe_v3_handoff_20260426_220631`

Handoff zip:
- `/gfs/space/private/wujn/Learn/agent-memory-server-bundle-v91-20260426-reader-probe-v3-qwen14/outputs/external_reader_probe_v3_handoff_20260426_220631.zip`

Primary files:
- `audit/reader_probe_handoff_summary.md`
- `audit/reader_probe_handoff_summary.csv`
- `audit/reader_error_examples.md`
- `audit/reader_unknown_examples.md`
- `audit/reader_temporal_examples.md`
- `reader_probe_outputs/`

Summary:

| benchmark | retrieval_variant | method | num_queries | relaxed_accuracy | exact_match | unknown_rate | json_object_rate | empty_gold_count | nonempty_relaxed_accuracy | wrong_avg_final_support_recall | top_failure_buckets | top_question_buckets | prompt_versions |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| locomo | hybrid_bge_m3_rerank | reader_llama31_8b_instruct | 1986 | 0.135952 | 0.074522 | 0.133434 | 0.985901 | 444 | 0.175097 | 0.811207 | supported_but_wrong:1124; confident_selection_error:325; retrieval_miss:264; comparative_reasoning:2; empty_prediction:1 | generic:777; when:270; item_name:157; title_or_name:137; event_name:73; where:63; group_name:43; person_name:42 | reader_json_evidence_v3_temporal_nonabstain |
| locomo | hybrid_bge_m3_rerank | reader_qwen25_14b_instruct | 1986 | 0.125378 | 0.072508 | 0.504532 | 0.999496 | 444 | 0.161479 | 0.811007 | supported_but_wrong:801; confident_selection_error:667; retrieval_miss:268; comparative_reasoning:1 | generic:776; when:270; item_name:160; title_or_name:134; event_name:72; where:68; group_name:45; person_name:43 | reader_json_evidence_v3_temporal_nonabstain |
| locomo | hybrid_bge_m3_rerank | reader_qwen25_7b_instruct | 1986 | 0.115307 | 0.066465 | 0.440584 | 0.997986 | 444 | 0.148508 | 0.812365 | supported_but_wrong:842; confident_selection_error:644; retrieval_miss:268; comparative_reasoning:3 | generic:782; when:270; item_name:162; title_or_name:139; event_name:73; where:65; person_name:43; group_name:43 | reader_json_evidence_v3_temporal_nonabstain |
| longmemeval | hybrid_bge_m3_rerank | reader_llama31_8b_instruct | 500 | 0.138000 | 0.096000 | 0.228000 | 0.988000 | 0 | 0.138000 | 0.936852 | supported_but_wrong:208; confident_selection_error:184; comparative_reasoning:24; retrieval_miss:14; empty_prediction:1 | quantity:142; generic:95; price:35; duration:23; where:18; title_or_name:17; event_name:17; judgment:17 | reader_json_evidence_v3_temporal_nonabstain |
| longmemeval | hybrid_bge_m3_rerank | reader_qwen25_14b_instruct | 500 | 0.126000 | 0.088000 | 0.498000 | 0.996000 | 0 | 0.126000 | 0.936117 | confident_selection_error:231; supported_but_wrong:167; comparative_reasoning:25; retrieval_miss:14 | quantity:147; generic:93; price:35; duration:24; title_or_name:18; where:17; event_name:17; judgment:16 | reader_json_evidence_v3_temporal_nonabstain |
| longmemeval | hybrid_bge_m3_rerank | reader_qwen25_7b_instruct | 500 | 0.126000 | 0.084000 | 0.528000 | 0.990000 | 0 | 0.126000 | 0.937338 | confident_selection_error:233; supported_but_wrong:164; comparative_reasoning:26; retrieval_miss:14 | quantity:140; generic:96; price:37; duration:24; where:19; title_or_name:17; event_name:17; judgment:17 | reader_json_evidence_v3_temporal_nonabstain |
