# Agent Memory Server Bundle

This bundle keeps the full method code and strips only the historical `outputs/` baggage.

## Included

- `src/memory_collapse/`
- `scripts/`
- `tests/test_external_pipeline.py`
- `artifacts/external_answer_models/`
- `docs/`
- `requirements_external.txt`

## Not Included

- historical `outputs/external_runs*`
- old probe directories
- local paper figures and large result dumps

That is intentional. The server should produce a fresh freeze run.

## Minimal external-answer artifacts

`artifacts/external_answer_models/` contains the inference-only models needed by:

- `proposed_learned_direct_valid`
- `proposed_learned_direct_valid_resolver`

Those files are enough for answer-level external evaluation. They are copied from the local synthetic model bundle and do not include the large training-example CSVs.

## Recommended baseline models

For the first server pass, I recommend:

1. `Qwen2.5-7B-Instruct`
2. `Meta-Llama-3.1-8B-Instruct`

Why this pair:

- same rough deployment class
- both are official instruct checkpoints
- good enough to establish whether your structured method is already competitive

If you have more GPU headroom, the next model I would add is:

3. `Qwen2.5-14B-Instruct`

I do **not** recommend using `Llama-2-13B` or unofficial `Llama-3-13B` merges as your main paper baseline. They are less clean as reviewer-facing baselines than an official Meta checkpoint.

## Upload Flow

1. Copy this directory or the zip to the GPU server.
2. Unzip it into a clean workspace, for example:

```bash
mkdir -p ~/runs/agent-memory
cd ~/runs/agent-memory
unzip agent-memory-server-bundle-v90-20260422-final-package.zip
cd agent-memory-server-bundle-v90-20260422-final
```

## Environment Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -r requirements_external.txt
```

If your server already has a compatible PyTorch install, keep it and only install the remaining dependencies as needed.

## Step 1: Retrieval Freeze

Set the raw benchmark paths and retrieval model paths:

```bash
export PROJECT_ROOT=$(pwd)
export PYTHON_BIN=python
export PYTHONPATH=$PROJECT_ROOT/src

export LONGMEMEVAL_INPUT=/path/to/longmemeval_raw.jsonl
export LOCOMO_INPUT=/path/to/locomo10.json

export E5_MODEL_PATH=/path/to/intfloat/e5-base-v2
export BGE_M3_MODEL_PATH=/path/to/BAAI/bge-m3
export RERANKER_MODEL_PATH=/path/to/BAAI/bge-reranker-v2-m3
```

Run the formal retrieval freeze:

```bash
chmod +x scripts/run_external_benchmark.sh scripts/run_external_dual_h800.sh scripts/run_external_answer_freeze.sh scripts/run_external_open_model_baselines.sh
FORMAL_FREEZE_SETTINGS=1 FORCE_RERUN=1 bash scripts/run_external_dual_h800.sh
```

This produces retrieval outputs under:

- `outputs/external_runs/longmemeval/`
- `outputs/external_runs/locomo/`

## Step 2: Answer-Level Freeze

The freeze script now supports both:

- the existing structured methods
- local open-model reader baselines

If your two reader checkpoints live under the same parent directory, you only need to edit one line in [run_external_open_model_baselines.sh](</D:/写码专用/agent memory/agent-memory-server-bundle-v90-20260422-final/scripts/run_external_open_model_baselines.sh>):

```bash
OPEN_MODEL_HOME=/path/to/local_hf_models
```

Expected default subdirectories under that parent:

- `Qwen2.5-7B-Instruct`
- `Meta-Llama-3.1-8B-Instruct`

If your folder names differ, override either of these instead:

```bash
export QWEN_MODEL_PATH=/path/to/Qwen2.5-7B-Instruct
export LLAMA_MODEL_PATH=/path/to/Meta-Llama-3.1-8B-Instruct
```

Run:

```bash
bash scripts/run_external_answer_freeze.sh
```

By default this writes to:

- `outputs/external_freeze_v90_aligned_r1/summary_longmemeval/`
- `outputs/external_freeze_v90_aligned_r1/summary_locomo/`
- `outputs/external_freeze_v90_aligned_r1/failure_slices/`

That single command now does three things in order:

1. runs `retrieval_only_baseline`
2. runs `proposed_learned_direct_valid` and `proposed_learned_direct_valid_resolver`
3. runs `reader_qwen25_7b_instruct` and `reader_llama31_8b_instruct` if the model paths exist

If you want to skip the open-model baselines for one pass:

```bash
RUN_OPEN_MODEL_BASELINES=0 bash scripts/run_external_answer_freeze.sh
```

## Step 3: Pull Back These Results

These are the main files to bring back to the local archive:

- `outputs/external_freeze_v90_aligned_r1/summary_longmemeval/external_end_to_end_summary.csv`
- `outputs/external_freeze_v90_aligned_r1/summary_locomo/external_end_to_end_summary.csv`
- `outputs/external_freeze_v90_aligned_r1/failure_slices/failure_slices_by_question.csv`
- `outputs/external_freeze_v90_aligned_r1/failure_slices/failure_slices_by_bucket.csv`
- `outputs/external_freeze_v90_aligned_r1/failure_slices/failure_slices.md`

If you want detailed postmortem analysis later, also pull back:

- `outputs/external_freeze_v90_aligned_r1/<benchmark>/<variant>/<method>/prediction_diagnostics.jsonl`

## About Qwen / Llama Baselines

This bundle now includes a ready-made local Hugging Face reader-baseline runner.

It writes outputs in the same `prediction_diagnostics.jsonl` layout as the structured methods, so the summary tables and failure-slice scripts can consume them directly.

You can now compare:

- `retrieval_only_baseline`
- `proposed_learned_direct_valid`
- `proposed_learned_direct_valid_resolver`
- `reader_qwen25_7b_instruct`
- `reader_llama31_8b_instruct`
- optionally `Qwen2.5-14B-Instruct`

## Do You Need to Rerun Retrieval?

I confirmed that the local research archive already has formal retrieval outputs for all five variants under [outputs/external_runs](</D:/写码专用/agent memory/agent-memory-clean/outputs/external_runs>):

- `tfidf`
- `dense_e5`
- `dense_e5_rerank`
- `hybrid_bge_m3`
- `hybrid_bge_m3_rerank`

Both `longmemeval` and `locomo` have `retrieval_summary.json` files with the formal settings:

- `retrieve_top_k = 20`
- `final_top_k = 10`

So the answer is:

- if you bring those existing `outputs/external_runs/...` retrieval results to the server, you do **not** need to rerun retrieval
- if you use this clean bundle as-is, you **do** need to run retrieval once on the server, because the bundle intentionally omits historical `outputs/`

You only need retrieval once per benchmark and variant. After those files exist on the server, the structured methods and the Qwen/Llama baselines all reuse the same retrieval diagnostics.
