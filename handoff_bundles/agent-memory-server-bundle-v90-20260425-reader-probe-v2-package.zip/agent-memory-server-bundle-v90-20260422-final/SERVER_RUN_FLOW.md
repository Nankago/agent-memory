# Server Run Flow

This file is the shortest complete path from local zip to a finished server run.

## Goal

Run all of the following on the GPU server:

- `retrieval_only_baseline`
- `proposed_learned_direct_valid`
- `proposed_learned_direct_valid_resolver`
- `reader_qwen25_7b_instruct`
- `reader_llama31_8b_instruct`

Benchmarks:

- `LongMemEval`
- `LoCoMo`

## Which Route Should You Use?

### Route A: Upload only the zip

Use this if you want the cleanest server-side freeze.

You will:

1. upload the zip
2. configure model paths
3. rerun retrieval on the server
4. run answer-level freeze and the two open-model baselines

### Route B: Upload the zip plus existing retrieval outputs

Use this if you want to save time.

You will:

1. upload the zip
2. upload local `outputs/external_runs/`
3. configure model paths
4. skip retrieval rerun
5. run answer-level freeze and the two open-model baselines

If retrieval code, checkpoints, and settings are identical, Route B should be effectively equivalent for paper purposes.

## What You Need On The Server

### Code package

Upload:

- `agent-memory-server-bundle-v90-20260423-final-package.zip`

### Benchmark inputs

You need local server copies of:

- LongMemEval raw input
- LoCoMo raw input

### Retrieval models

You need local server copies of:

- `intfloat/e5-base-v2`
- `BAAI/bge-m3`
- `BAAI/bge-reranker-v2-m3`

### Reader models

You need local server copies of:

- `Qwen2.5-7B-Instruct`
- `Meta-Llama-3.1-8B-Instruct`

## Recommended Server Layout

```text
~/runs/agent-memory/
  agent-memory-server-bundle-v90-20260423-final-package.zip
  agent-memory-server-bundle-v90-20260422-final/

~/models/
  intfloat/e5-base-v2/
  BAAI/bge-m3/
  BAAI/bge-reranker-v2-m3/
  Qwen2.5-7B-Instruct/
  Meta-Llama-3.1-8B-Instruct/

~/data/
  longmemeval_raw.jsonl
  locomo10.json
```

Note: the zip filename is `20260423`, but the directory inside the zip is still named:

```text
agent-memory-server-bundle-v90-20260422-final
```

That is expected.

## Step 1: Upload

From local machine:

```bash
scp agent-memory-server-bundle-v90-20260423-final-package.zip user@your-server:~/runs/agent-memory/
```

If you want Route B, also copy your local retrieval outputs:

```bash
scp -r outputs/external_runs user@your-server:~/runs/agent-memory/
```

## Step 2: SSH And Unzip

```bash
ssh user@your-server
cd ~/runs/agent-memory
unzip agent-memory-server-bundle-v90-20260423-final-package.zip
cd agent-memory-server-bundle-v90-20260422-final
```

## Step 3: Create Python Environment

```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -r requirements_external.txt
```

If your server already has a matching PyTorch install, keeping that is fine.

## Step 4: Export Core Paths

```bash
export PROJECT_ROOT=$(pwd)
export PYTHON_BIN=python
export PYTHONPATH=$PROJECT_ROOT/src

export LONGMEMEVAL_INPUT=~/data/longmemeval_raw.jsonl
export LOCOMO_INPUT=~/data/locomo10.json

export E5_MODEL_PATH=~/models/intfloat/e5-base-v2
export BGE_M3_MODEL_PATH=~/models/BAAI/bge-m3
export RERANKER_MODEL_PATH=~/models/BAAI/bge-reranker-v2-m3

export OPEN_MODEL_HOME=~/models
```

If your reader model folder names are different, override them directly:

```bash
export QWEN_MODEL_PATH=/your/path/to/Qwen2.5-7B-Instruct
export LLAMA_MODEL_PATH=/your/path/to/Meta-Llama-3.1-8B-Instruct
```

## Step 5A: Route A, Zip Only

If you uploaded only the zip, run retrieval first:

```bash
chmod +x scripts/run_external_benchmark.sh
chmod +x scripts/run_external_dual_h800.sh
chmod +x scripts/run_external_answer_freeze.sh
chmod +x scripts/run_external_open_model_baselines.sh

FORMAL_FREEZE_SETTINGS=1 FORCE_RERUN=1 bash scripts/run_external_dual_h800.sh
```

This will generate:

```text
outputs/external_runs/
```

with all five retrieval variants for both benchmarks.

## Step 5B: Route B, Reuse Existing Retrieval

If you uploaded your local `external_runs/`, place it here:

```text
$PROJECT_ROOT/outputs/external_runs/
```

Check it exists:

```bash
ls outputs/external_runs
ls outputs/external_runs/longmemeval
ls outputs/external_runs/locomo
```

If those directories are already there, you can skip retrieval rerun.

## Step 6: Run Structured Methods Plus Qwen / Llama

```bash
bash scripts/run_external_answer_freeze.sh
```

That single command now runs:

1. `retrieval_only_baseline`
2. `proposed_learned_direct_valid`
3. `proposed_learned_direct_valid_resolver`
4. `reader_qwen25_7b_instruct`
5. `reader_llama31_8b_instruct`

The open-model baselines are only skipped if their model paths do not exist.

## Optional: Skip Qwen / Llama For One Pass

```bash
RUN_OPEN_MODEL_BASELINES=0 bash scripts/run_external_answer_freeze.sh
```

## Optional: Reader Probe V2

If the Qwen / LLaMA reader rows look like long continuations instead of short answers, run the fixed reader probe:

```bash
chmod +x scripts/run_external_reader_probe_v2.sh
bash scripts/run_external_reader_probe_v2.sh
```

This only reruns:

- `LongMemEval + hybrid_bge_m3_rerank + Qwen`
- `LoCoMo + hybrid_bge_m3_rerank + Qwen`
- `LongMemEval + hybrid_bge_m3_rerank + LLaMA`
- `LoCoMo + hybrid_bge_m3_rerank + LLaMA`

It writes to:

```text
outputs/external_reader_probe_v2/
```

See `RUN_READER_PROBE_V2.md` for details.

## Where Results Go

Main output root:

```text
outputs/external_freeze_v90_aligned_r1/
```

Most important files:

- `outputs/external_freeze_v90_aligned_r1/summary_longmemeval/external_end_to_end_summary.csv`
- `outputs/external_freeze_v90_aligned_r1/summary_locomo/external_end_to_end_summary.csv`
- `outputs/external_freeze_v90_aligned_r1/failure_slices/failure_slices_by_question.csv`
- `outputs/external_freeze_v90_aligned_r1/failure_slices/failure_slices_by_bucket.csv`
- `outputs/external_freeze_v90_aligned_r1/failure_slices/failure_slices.md`

Detailed per-method outputs:

```text
outputs/external_freeze_v90_aligned_r1/<benchmark>/<variant>/<method>/prediction_diagnostics.jsonl
outputs/external_freeze_v90_aligned_r1/<benchmark>/<variant>/<method>/metrics.json
```

## Fast Sanity Checks

Check that summary files exist:

```bash
ls outputs/external_freeze_v90_aligned_r1/summary_longmemeval
ls outputs/external_freeze_v90_aligned_r1/summary_locomo
ls outputs/external_freeze_v90_aligned_r1/failure_slices
```

Check that the open-model methods were written:

```bash
find outputs/external_freeze_v90_aligned_r1 -type d | grep reader_qwen25_7b_instruct
find outputs/external_freeze_v90_aligned_r1 -type d | grep reader_llama31_8b_instruct
```

## Recommended First Real Run

If you are short on time and want the cleanest practical run:

1. upload the zip
2. upload `outputs/external_runs/`
3. set all model paths
4. run:

```bash
bash scripts/run_external_answer_freeze.sh
```

That is the fastest end-to-end path.

## Practical Recommendation

For your current situation, the most efficient workflow is:

- use the small zip for code
- reuse local `outputs/external_runs/` if server transfer is acceptable
- avoid re-running retrieval unless you specifically want a fully fresh server-only freeze

If you use only the zip and do not upload `external_runs/`, that is still fine; it just adds the retrieval stage before the answer-level stage.
