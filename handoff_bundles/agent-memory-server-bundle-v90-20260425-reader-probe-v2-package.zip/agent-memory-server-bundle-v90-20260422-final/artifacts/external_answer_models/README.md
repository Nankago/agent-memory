These files are the minimal inference-only artifacts for the external answer-level methods:

- `rho_model.pkl`
- `query_validity_useful_model.pkl`
- `query_validity_valid_model.pkl`
- `anti_support_model.pkl`
- `value_resolver_model.pkl`

They were copied from the local source bundle:

- `outputs/default_direct_validity_v12/models/`

They are intended for:

- `proposed_learned_direct_valid`
- `proposed_learned_direct_valid_resolver`

They intentionally exclude the large training-example CSVs and historical run outputs.
