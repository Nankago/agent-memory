from __future__ import annotations

import csv
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from memory_collapse.baselines import _softmax_confidence
from memory_collapse.external_pipeline import (
    ExternalRetrievedCase,
    _answer_matches,
    _build_external_method_inputs,
    _load_retrieval_cases,
    _normalized_answer,
    _render_summary_markdown,
    _select_candidate_rows,
    _serialize_value_scores,
    _summary_projection,
    _summarize_method_run,
    _value_to_context_ids,
)
from memory_collapse.io_utils import ensure_dir, write_csv, write_jsonl
from memory_collapse.relevance import normalized_similarity


QWEN25_7B_READER_METHOD = "reader_qwen25_7b_instruct"
LLAMA31_8B_READER_METHOD = "reader_llama31_8b_instruct"
SUPPORTED_READER_METHODS = {
    QWEN25_7B_READER_METHOD,
    LLAMA31_8B_READER_METHOD,
}

DEFAULT_SYSTEM_PROMPT = (
    "You answer questions from quoted evidence snippets. "
    "Do not continue or imitate the snippets. "
    'Return exactly one JSON object like {"answer":"short answer"}.'
)
DEFAULT_SNIPPET_CHAR_LIMIT = 700


@dataclass(frozen=True)
class ReaderCaseInputs:
    case: ExternalRetrievedCase
    candidate_rows: list[dict[str, Any]]
    candidate_source: str
    pseudo_memories: list[dict[str, Any]]
    prompt_text: str


class HuggingFaceReader:
    def __init__(
        self,
        model_name_or_path: str | Path,
        *,
        device: str = "cuda",
        max_new_tokens: int = 24,
        max_input_tokens: int = 6144,
    ) -> None:
        transformers, torch = _load_transformer_stack()
        self._torch = torch
        self._transformers = transformers
        self.model_name_or_path = str(model_name_or_path)
        self.device = device
        self.max_new_tokens = int(max_new_tokens)
        self.max_input_tokens = int(max_input_tokens)

        tokenizer = transformers.AutoTokenizer.from_pretrained(
            self.model_name_or_path,
            trust_remote_code=True,
        )
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token or tokenizer.unk_token
        tokenizer.padding_side = "left"
        tokenizer.truncation_side = "left"

        model_dtype = _resolve_torch_dtype(torch, device)
        model = transformers.AutoModelForCausalLM.from_pretrained(
            self.model_name_or_path,
            torch_dtype=model_dtype,
            trust_remote_code=True,
        )
        if device and device != "cpu":
            if not torch.cuda.is_available():
                raise RuntimeError("reader device was set to cuda, but CUDA is not available.")
            model = model.to(device)
        model.eval()

        self.tokenizer = tokenizer
        self.model = model
        self._pad_token_id = tokenizer.pad_token_id or tokenizer.eos_token_id
        self._eos_token_id = tokenizer.eos_token_id

    def generate_batch(self, prompt_texts: list[str]) -> list[str]:
        if not prompt_texts:
            return []
        rendered_prompts = [self._render_prompt(prompt_text) for prompt_text in prompt_texts]
        inputs = self.tokenizer(
            rendered_prompts,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=self.max_input_tokens,
        )
        if self.device and self.device != "cpu":
            inputs = {key: value.to(self.device) for key, value in inputs.items()}

        with self._torch.inference_mode():
            output_ids = self.model.generate(
                **inputs,
                max_new_tokens=self.max_new_tokens,
                do_sample=False,
                pad_token_id=self._pad_token_id,
                eos_token_id=self._eos_token_id,
                use_cache=True,
            )

        prompt_token_count = inputs["input_ids"].shape[1]
        generated_ids = output_ids[:, prompt_token_count:]
        decoded = self.tokenizer.batch_decode(generated_ids, skip_special_tokens=True)
        return [str(text).strip() for text in decoded]

    def _render_prompt(self, prompt_text: str) -> str:
        messages = [
            {"role": "system", "content": DEFAULT_SYSTEM_PROMPT},
            {"role": "user", "content": prompt_text},
        ]
        apply_chat_template = getattr(self.tokenizer, "apply_chat_template", None)
        if apply_chat_template is not None:
            try:
                return str(
                    apply_chat_template(
                        messages,
                        tokenize=False,
                        add_generation_prompt=True,
                    )
                )
            except Exception:
                pass
        return f"System: {DEFAULT_SYSTEM_PROMPT}\n\nUser: {prompt_text}\n\nAssistant:"


class ExternalReaderBaselineRunner:
    def __init__(
        self,
        benchmark_name: str,
        output_root: str | Path,
        *,
        method_name: str,
        reader_model_path: str | Path,
        top_k: int | None = None,
        final_k: int | None = None,
        summary_root: str | Path | None = None,
        reader_device: str = "cuda",
        reader_batch_size: int = 2,
        reader_max_new_tokens: int = 24,
        reader_max_input_tokens: int = 6144,
    ) -> None:
        if method_name not in SUPPORTED_READER_METHODS:
            raise ValueError(
                f"Unsupported reader method: {method_name}. "
                f"Supported methods: {', '.join(sorted(SUPPORTED_READER_METHODS))}."
            )
        self.benchmark_name = benchmark_name.lower()
        self.output_root = ensure_dir(output_root)
        self.method_name = method_name
        self.reader_model_path = Path(reader_model_path)
        self.top_k = int(top_k) if top_k else None
        self.final_k = int(final_k) if final_k else None
        self.summary_root = ensure_dir(summary_root or output_root)
        self.reader_device = reader_device
        self.reader_batch_size = max(int(reader_batch_size), 1)
        self.reader_max_new_tokens = int(reader_max_new_tokens)
        self.reader_max_input_tokens = int(reader_max_input_tokens)
        self._reader: HuggingFaceReader | None = None

    def run(self, retrieval_inputs: dict[str, str | Path]) -> dict[str, str]:
        if not self.reader_model_path.exists():
            raise FileNotFoundError(f"Reader model path does not exist: {self.reader_model_path}")

        all_metric_rows: list[dict[str, Any]] = []
        written_diagnostics: dict[str, str] = {}
        for retrieval_variant, input_dir in retrieval_inputs.items():
            cases = _load_retrieval_cases(input_dir, self.benchmark_name, retrieval_variant)
            diagnostics_rows = self._run_cases(cases)
            metrics_row = _summarize_method_run(
                benchmark=self.benchmark_name,
                retrieval_variant=retrieval_variant,
                method=self.method_name,
                diagnostics_rows=diagnostics_rows,
            )
            metrics_row["notes"] = _reader_summary_note(self.method_name, self.reader_model_path)
            all_metric_rows.append(metrics_row)

            method_dir = ensure_dir(self.output_root / self.benchmark_name / retrieval_variant / self.method_name)
            diagnostics_path = write_jsonl(method_dir / "prediction_diagnostics.jsonl", diagnostics_rows)
            write_csv(method_dir / "metrics.csv", [metrics_row])
            with (method_dir / "metrics.json").open("w", encoding="utf-8") as handle:
                json.dump(metrics_row, handle, indent=2)
            written_diagnostics[retrieval_variant] = str(diagnostics_path)

        metrics_csv_path, summary_csv_path, summary_md_path = _merge_summary_tables(
            self.summary_root,
            all_metric_rows,
        )
        return {
            "metrics_csv": str(metrics_csv_path),
            "summary_csv": str(summary_csv_path),
            "summary_md": str(summary_md_path),
            "diagnostics": written_diagnostics,
        }

    def _run_cases(self, cases: list[ExternalRetrievedCase]) -> list[dict[str, Any]]:
        prepared_cases = [self._prepare_case(case) for case in cases]
        diagnostics_rows: list[dict[str, Any]] = []
        for batch_start in range(0, len(prepared_cases), self.reader_batch_size):
            batch = prepared_cases[batch_start : batch_start + self.reader_batch_size]
            raw_outputs = self._get_reader().generate_batch([item.prompt_text for item in batch])
            for item, raw_output in zip(batch, raw_outputs):
                diagnostics_rows.append(self._build_diagnostic_row(item, raw_output))
        return diagnostics_rows

    def _prepare_case(self, case: ExternalRetrievedCase) -> ReaderCaseInputs:
        candidate_rows, candidate_source = _select_candidate_rows(
            case,
            top_k=self.top_k,
            final_k=self.final_k,
        )
        _, pseudo_memories = _build_external_method_inputs(case, candidate_rows, candidate_source)
        prompt_text = _build_reader_prompt(case.prompt, candidate_rows)
        return ReaderCaseInputs(
            case=case,
            candidate_rows=candidate_rows,
            candidate_source=candidate_source,
            pseudo_memories=pseudo_memories,
            prompt_text=prompt_text,
        )

    def _build_diagnostic_row(self, item: ReaderCaseInputs, raw_output: str) -> dict[str, Any]:
        raw_answer = _clean_model_answer(raw_output)
        value_to_ids = _value_to_context_ids(item.pseudo_memories)
        value_scores = _value_scores_from_retrieval(item.candidate_rows, item.pseudo_memories)
        matched_values = _match_candidate_values(item.case.prompt, raw_answer, list(value_scores))

        predicted_answer = raw_answer
        if matched_values:
            for value in matched_values:
                value_scores[value] = float(value_scores.get(value, 0.0)) + 1.0
            predicted_answer = max(
                matched_values,
                key=lambda value: (float(value_scores.get(value, 0.0)), value),
            )
        elif predicted_answer and _normalized_answer(predicted_answer) != "unknown":
            boost = max((float(score) for score in value_scores.values()), default=0.0) + 0.2
            value_scores[predicted_answer] = max(float(value_scores.get(predicted_answer, 0.0)), boost)

        chosen_ids = value_to_ids.get(predicted_answer, [])
        exact_match = _normalized_answer(predicted_answer) == _normalized_answer(item.case.gold_answer)
        is_correct = _answer_matches(item.case.prompt, predicted_answer, item.case.gold_answer)
        retrieval_support_final = item.case.raw_row.get("support_recall_at_final_k")
        retrieval_support_retrieve = item.case.raw_row.get("support_recall_at_retrieve_k")
        retrieval_hit_at_1 = item.case.raw_row.get("support_hit_at_1")
        retrieval_mrr = item.case.raw_row.get("support_mrr")

        return {
            "benchmark": item.case.benchmark,
            "variant": item.case.retrieval_variant,
            "method": self.method_name,
            "query_id": item.case.query_id,
            "gold_answer": item.case.gold_answer,
            "predicted_answer": predicted_answer,
            "is_correct": bool(is_correct),
            "exact_match": bool(exact_match),
            "retrieved_ids": [str(row["memory_id"]) for row in item.candidate_rows],
            "candidate_value_scores": _serialize_value_scores(value_scores, value_to_ids),
            "chosen_value": predicted_answer,
            "confidence": float(_softmax_confidence(value_scores)) if value_scores else 0.0,
            "supporting_context_ids": chosen_ids,
            "answer_support_ids": item.case.answer_support_ids,
            "candidate_pool_source": item.candidate_source,
            "num_candidate_contexts": len(item.candidate_rows),
            "retrieval_support_recall_at_retrieve_k": retrieval_support_retrieve,
            "retrieval_support_recall_at_final_k": retrieval_support_final,
            "hit_at_1": retrieval_hit_at_1,
            "mrr": retrieval_mrr,
            "resolver_metadata": None,
            "direct_valid_metadata": {
                "baseline_type": "open_model_reader",
                "reader_method": self.method_name,
                "reader_model_path": str(self.reader_model_path),
                "reader_model_name": self.reader_model_path.name,
                "reader_device": self.reader_device,
                "reader_prompt_version": "reader_json_evidence_v2",
                "raw_model_output": raw_output,
                "matched_candidate_values": matched_values,
                "pool_source": item.candidate_source,
                "num_candidate_contexts": len(item.candidate_rows),
            },
        }

    def _get_reader(self) -> HuggingFaceReader:
        if self._reader is None:
            self._reader = HuggingFaceReader(
                self.reader_model_path,
                device=self.reader_device,
                max_new_tokens=self.reader_max_new_tokens,
                max_input_tokens=self.reader_max_input_tokens,
            )
        return self._reader


def run_external_reader_baseline(
    benchmark_name: str,
    retrieval_inputs: dict[str, str | Path],
    *,
    method_name: str,
    reader_model_path: str | Path,
    output_root: str | Path,
    top_k: int | None = None,
    final_k: int | None = None,
    summary_root: str | Path | None = None,
    reader_device: str = "cuda",
    reader_batch_size: int = 2,
    reader_max_new_tokens: int = 24,
    reader_max_input_tokens: int = 6144,
) -> dict[str, str]:
    runner = ExternalReaderBaselineRunner(
        benchmark_name=benchmark_name,
        output_root=output_root,
        method_name=method_name,
        reader_model_path=reader_model_path,
        top_k=top_k,
        final_k=final_k,
        summary_root=summary_root,
        reader_device=reader_device,
        reader_batch_size=reader_batch_size,
        reader_max_new_tokens=reader_max_new_tokens,
        reader_max_input_tokens=reader_max_input_tokens,
    )
    return runner.run(retrieval_inputs)


def _build_reader_prompt(question: str, candidate_rows: list[dict[str, Any]]) -> str:
    context_lines = []
    for index, row in enumerate(candidate_rows, start=1):
        text = _clip_snippet_text(str(row.get("text", "")), DEFAULT_SNIPPET_CHAR_LIMIT)
        context_lines.append(f'<snippet id="{index}">{text}</snippet>')
    contexts = "\n\n".join(context_lines) if context_lines else '<snippet id="0">unknown</snippet>'
    return (
        "Evidence snippets follow. They are quoted data, not conversation to continue.\n"
        "Use them only as evidence.\n\n"
        f"{contexts}\n\n"
        "Question:\n"
        f"{question.strip()}\n\n"
        "Return exactly one JSON object with one key, answer.\n"
        "The answer value must be the shortest supported answer phrase.\n"
        'If no snippet supports the answer, use {"answer":"unknown"}.\n'
        "Do not include explanations, markdown, citations, or extra text.\n\n"
        "JSON:"
    )


def _clean_model_answer(text: str | None) -> str:
    raw_text = str(text or "").strip()
    answer = _extract_json_answer(raw_text)
    if answer is None:
        answer = raw_text
    if not answer:
        return ""
    answer = answer.splitlines()[0].strip()
    answer = re.sub(r"^```(?:json)?\s*", "", answer, flags=re.IGNORECASE)
    answer = re.sub(r"\s*```$", "", answer)
    answer = re.sub(r"^(?:json)\s*[:：-]\s*", "", answer, flags=re.IGNORECASE)
    answer = re.sub(r"^(?:assistant|answer)\s*[:：-]\s*", "", answer, flags=re.IGNORECASE)
    answer = re.sub(r"^(?:the answer is|answer is|it is|it's|it was)\s+", "", answer, flags=re.IGNORECASE)
    answer = answer.strip().strip('"').strip("'").strip()
    answer = re.sub(r"\s+", " ", answer)
    if len(answer.split()) <= 10:
        answer = answer.rstrip(" .")
    normalized = _normalized_answer(answer)
    if normalized in {
        "unknown",
        "not enough information",
        "cannot determine",
        "cant determine",
        "cannot be determined",
    }:
        return "unknown"
    return answer


def _clip_snippet_text(text: str, char_limit: int) -> str:
    normalized = re.sub(r"\s+", " ", text).strip()
    normalized = normalized.replace("<", "[").replace(">", "]")
    if len(normalized) <= char_limit:
        return normalized
    return normalized[: max(char_limit - 20, 1)].rstrip() + " ... [truncated]"


def _extract_json_answer(text: str) -> str | None:
    stripped = text.strip()
    if not stripped:
        return None
    stripped = re.sub(r"^```(?:json)?\s*", "", stripped, flags=re.IGNORECASE).strip()
    stripped = re.sub(r"\s*```$", "", stripped).strip()
    decoder = json.JSONDecoder()
    candidates = [stripped]
    first_brace = stripped.find("{")
    last_brace = stripped.rfind("}")
    if 0 <= first_brace < last_brace:
        candidates.append(stripped[first_brace : last_brace + 1])
    for candidate in candidates:
        try:
            parsed, _ = decoder.raw_decode(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict) and "answer" in parsed:
            return str(parsed.get("answer") or "").strip()
    match = re.search(r'"answer"\s*:\s*"([^"]*)"', stripped, flags=re.IGNORECASE | re.DOTALL)
    if match:
        return match.group(1).strip()
    return None


def _value_scores_from_retrieval(
    candidate_rows: list[dict[str, Any]],
    pseudo_memories: list[dict[str, Any]],
) -> dict[str, float]:
    memory_by_id = {str(memory["memory_id"]): memory for memory in pseudo_memories}
    raw_scores = {
        str(row["memory_id"]): float(row.get("score", 0.0))
        for row in candidate_rows
    }
    normalized_scores = normalized_similarity(raw_scores) if raw_scores else {}
    value_scores: dict[str, float] = {}
    for row in candidate_rows:
        memory = memory_by_id.get(str(row["memory_id"]))
        if memory is None:
            continue
        value = str(memory.get("value_canonical") or "").strip()
        if not value:
            continue
        value_scores[value] = max(value_scores.get(value, float("-inf")), normalized_scores.get(str(row["memory_id"]), 0.0))
    return value_scores


def _match_candidate_values(prompt: str, predicted_answer: str, candidate_values: list[str]) -> list[str]:
    normalized_predicted = _normalized_answer(predicted_answer)
    if not normalized_predicted or normalized_predicted == "unknown":
        return []
    matches: list[tuple[int, int, str]] = []
    for value in candidate_values:
        normalized_value = _normalized_answer(value)
        if not normalized_value:
            continue
        if normalized_predicted == normalized_value:
            matches.append((3, len(normalized_value), value))
            continue
        if normalized_value in normalized_predicted or normalized_predicted in normalized_value:
            matches.append((2, len(normalized_value), value))
            continue
        if _answer_matches(prompt, predicted_answer, value) or _answer_matches(prompt, value, predicted_answer):
            matches.append((1, len(normalized_value), value))
    matches.sort(reverse=True)
    return [value for _, _, value in matches]


def _reader_summary_note(method_name: str, reader_model_path: Path) -> str:
    model_name = reader_model_path.name
    if method_name == QWEN25_7B_READER_METHOD:
        return f"Open-model reader baseline using {model_name} on the retrieved top-k snippets."
    if method_name == LLAMA31_8B_READER_METHOD:
        return f"Open-model reader baseline using {model_name} on the retrieved top-k snippets."
    return f"Open-model reader baseline using {model_name}."


def _load_transformer_stack():
    try:
        import torch
        import transformers
    except ImportError as exc:
        raise RuntimeError(
            "Local reader baselines require `torch` and `transformers` in the runtime environment."
        ) from exc
    return transformers, torch


def _resolve_torch_dtype(torch: Any, device: str):
    if device == "cpu":
        return torch.float32
    if hasattr(torch.cuda, "is_bf16_supported") and torch.cuda.is_available() and torch.cuda.is_bf16_supported():
        return torch.bfloat16
    return torch.float16


def _read_csv_rows(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _merge_summary_tables(summary_root: Path, new_metric_rows: list[dict[str, Any]]) -> tuple[Path, Path, Path]:
    metrics_csv_path = summary_root / "external_end_to_end_metrics.csv"
    existing_metric_rows = _read_csv_rows(metrics_csv_path)
    combined_metric_rows = _merge_rows(
        existing_metric_rows,
        new_metric_rows,
        key_fields=("benchmark", "retrieval_variant", "method"),
    )
    combined_metric_rows = sorted(
        combined_metric_rows,
        key=lambda row: (
            str(row.get("benchmark", "")),
            str(row.get("retrieval_variant", "")),
            str(row.get("method", "")),
        ),
    )
    write_csv(metrics_csv_path, combined_metric_rows)

    summary_rows = [_summary_projection(row) for row in combined_metric_rows]
    summary_csv_path = summary_root / "external_end_to_end_summary.csv"
    write_csv(summary_csv_path, summary_rows)

    summary_md_path = summary_root / "external_end_to_end_summary.md"
    summary_md_path.write_text(_render_summary_markdown(summary_rows), encoding="utf-8")
    return metrics_csv_path, summary_csv_path, summary_md_path


def _merge_rows(
    existing_rows: list[dict[str, Any]],
    new_rows: list[dict[str, Any]],
    *,
    key_fields: tuple[str, ...],
) -> list[dict[str, Any]]:
    row_by_key: dict[tuple[str, ...], dict[str, Any]] = {}
    for row in existing_rows:
        key = tuple(str(row.get(field, "")) for field in key_fields)
        row_by_key[key] = row
    for row in new_rows:
        key = tuple(str(row.get(field, "")) for field in key_fields)
        row_by_key[key] = row
    return list(row_by_key.values())
