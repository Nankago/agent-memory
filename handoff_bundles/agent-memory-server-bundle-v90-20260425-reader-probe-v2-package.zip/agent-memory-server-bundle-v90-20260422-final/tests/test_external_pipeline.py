from __future__ import annotations

import importlib
from pathlib import Path

import pandas as pd
import pytest

from memory_collapse.baselines import DIRECT_VALID_METHOD, DIRECT_VALID_RESOLVER_METHOD
from memory_collapse.external_pipeline import (
    ExternalMethodBundles,
    RETRIEVAL_ONLY_BASELINE,
    _apply_method_specific_judgment_adjustments,
    _answer_contains_gold,
    _answer_matches,
    _anchor_relative_date,
    _build_event_reasoning_adapter_candidate,
    _build_reasoning_adapter_candidate,
    _build_generic_reasoning_adapter_candidate,
    _extract_candidate_answer,
    _extract_painted_prompt_items,
    _extract_prompt_choice_candidates,
    _infer_answer_type,
    _is_comparative_prompt,
    _is_salutation_clause,
    _looks_like_person_or_group_candidate,
    _normalize_painted_prompt_item,
    _prompt_family_candidate_bonus,
    _prompt_session_date_alignment,
    _run_external_learned_method,
    run_external_end_to_end,
)
from memory_collapse.external_pipeline_v0 import run_external_end_to_end as run_external_end_to_end_v0
from memory_collapse.io_utils import read_jsonl, write_jsonl


class _FakeRelevanceBundle:
    def predict_relevance(self, query, memory, tfidf_score, observable_context=None):
        text = str(memory["memory_text"]).lower()
        score = 0.25 + 0.55 * float(tfidf_score)
        if "berlin" in text or "travel refund" in text:
            score += 0.20
        return max(0.02, min(0.99, score))


class _FakeQueryValidityBundle:
    def __init__(self, target_label: str):
        self.target_label = target_label
        self.condition = "relevant_only"

    def predict_query_validity(self, query, memory, tfidf_score, observable_context=None):
        text = str(memory["memory_text"]).lower()
        score = 0.30 + 0.40 * float(tfidf_score)
        if "berlin" in text or "travel refund" in text:
            score += 0.25
        if "apples" in text or "identity" in text:
            score -= 0.10
        return max(0.02, min(0.99, score))


class _FakeAntiSupportBundle:
    def predict_anti_support(self, feature_dict):
        return 0.10


class _FakeValueResolverBundle:
    condition = "top_k_direct_valid_candidates"
    objective = "candidate_binary_classification"

    def predict_candidate_scores(self, feature_rows):
        scores: list[float] = []
        for row in feature_rows:
            scores.append(
                float(row.get("candidate_support_sum", 0.0))
                + 0.10 * float(row.get("candidate_rho_mean", 0.0))
                - 0.10 * float(row.get("candidate_self_anti_sum", 0.0))
            )
        return scores


class _TinyRelevanceBundle:
    def predict_relevance(self, query, memory, tfidf_score, observable_context=None):
        value = str(memory["value_canonical"]).lower()
        score = 1e-9 + 2e-7 * float(tfidf_score)
        if "target" in value or "yesterday" in value:
            score += 8e-6
        if memory.get("entity") == query.get("entity"):
            score += 2e-6
        return score


class _TinyQueryValidityBundle:
    def __init__(self, target_label: str):
        self.target_label = target_label
        self.condition = "relevant_only"

    def predict_query_validity(self, query, memory, tfidf_score, observable_context=None):
        value = str(memory["value_canonical"]).lower()
        score = 1e-10 + 1e-7 * float(tfidf_score)
        if "target" in value or "yesterday" in value:
            score += 5e-6
        if memory.get("entity") == query.get("entity"):
            score += 1e-6
        return score


class _TinyAntiSupportBundle:
    def predict_anti_support(self, feature_dict):
        text = " ".join(f"{key}={value}" for key, value in sorted(feature_dict.items()))
        return 1e-6 if "target" in text or "yesterday" in text else 5e-5


class _ConstantRelevanceBundle:
    def predict_relevance(self, query, memory, tfidf_score, observable_context=None):
        return 0.5


class _ConstantQueryValidityBundle:
    condition = "relevant_only"

    def predict_query_validity(self, query, memory, tfidf_score, observable_context=None):
        return 0.5


class _ConstantAntiSupportBundle:
    def predict_anti_support(self, feature_dict):
        return 0.1


def test_type_aware_extractor_prefers_short_answer_span():
    longmem_text = (
        "user: I'm trying to organize my coupons and receipts. "
        "I actually redeemed a $5 coupon on coffee creamer at Target last Friday.\n"
        "assistant: That sounds like a good use of the coupon."
    )
    locomo_text = (
        "Caroline: I went to a LGBTQ support group yesterday and it was so powerful.\n"
        "Melanie: That's wonderful, Caroline."
    )
    title_text = (
        "user: The play I attended was actually a production of The Glass Menagerie, have you heard of it?\n"
        "assistant: It's a classic."
    )
    holiday_text = (
        "user: I volunteered at the Love is in the Air fundraising dinner back on Valentine's Day.\n"
        "assistant: That sounds lovely."
    )
    game_text = (
        "John: Hey James! Long time no chat.\n"
        "James: I've been playing my favourite game called Apex Legends with my team and it's intense!\n"
        "John: That sounds fun."
    )
    project_text = (
        "Joanna: Hey Nate! I just joined a writers group.\n"
        "Joanna: I'm working on one with my group called \"Finding Home.\" It's a script about a girl on a journey.\n"
        "Nate: That's awesome."
    )
    comparative_event_text = (
        "user: I'm thinking of planning a small ceremony for my own wedding next year. "
        "By the way, I just came back from Michael's engagement party at a trendy rooftop bar today.\n"
        "assistant: That sounds exciting."
    )
    comparative_person_text = (
        "user: I'm considering adopting a baby boy from foster care. "
        "By the way, my cousin Alex just adopted a baby girl from China in January.\n"
        "assistant: That's wonderful news."
    )
    occupation_text = (
        "user: I've used Trello in my previous role as a marketing specialist at a small startup "
        "and I'm familiar with its features.\n"
        "assistant: ClickUp is another option."
    )
    gift_text = (
        "user: For my sister's birthday, I got her a yellow dress and a pair of earrings to match.\n"
        "assistant: That sounds lovely."
    )
    pet_name_text = (
        "user: By the way, my cat's name is Luna, and she's been such a sweetie.\n"
        "assistant: Luna sounds adorable."
    )
    brand_text = (
        "user: I've been using a lavender scented shampoo that I picked up on a whim at Trader Joe's.\n"
        "assistant: Trader Joe's has some great finds."
    )
    size_text = (
        "user: I actually just set up my new Samsung 55-inch 4K smart TV on Saturday.\n"
        "assistant: Nice setup."
    )
    ratio_text = (
        "user: Aim for a ratio of around 2:1 or 3:1 when balancing the drink.\n"
        "assistant: That should help."
    )
    relation_text = (
        "Maria: My mother and I made some dinner together last night!\n"
        "John: That sounds delicious."
    )
    movies_text = (
        "Nate: I love action and sci-fi movies, the effects are so cool!\n"
        "Joanna: Nice taste."
    )
    fan_text = (
        "Melanie: I'm a fan of both classical like Bach and modern music like Ed Sheeran's Perfect.\n"
        "Caroline: Nice range."
    )
    support_text = (
        "Caroline: My mentors, family, and friends are my rocks whenever I have a negative experience.\n"
        "Melanie: I'm glad you have them."
    )

    longmem_answer = _extract_candidate_answer(
        "Where did I redeem a $5 coupon on coffee creamer?",
        longmem_text,
        target_speaker="user",
    )
    locomo_answer = _extract_candidate_answer(
        "When did Caroline go to the LGBTQ support group?",
        locomo_text,
        target_speaker="caroline",
    )
    title_answer = _extract_candidate_answer(
        "What play did I attend at the local community theater?",
        title_text,
        target_speaker="user",
    )
    holiday_answer = _extract_candidate_answer(
        "When did I volunteer at the local animal shelter's fundraising dinner?",
        holiday_text,
        target_speaker="user",
    )
    game_answer = _extract_candidate_answer(
        "What game was James playing in the online gaming tournament?",
        game_text,
        target_speaker="james",
    )
    project_answer = _extract_candidate_answer(
        "What is Joanna's project called in the writers group?",
        project_text,
        target_speaker="joanna",
    )
    comparative_event_answer = _extract_candidate_answer(
        "Which event happened first, my cousin's wedding or Michael's engagement party?",
        comparative_event_text,
        target_speaker="user",
    )
    comparative_person_answer = _extract_candidate_answer(
        "Who became a parent first, Rachel or Alex?",
        comparative_person_text,
        target_speaker="user",
    )
    occupation_answer = _extract_candidate_answer(
        "What was my previous occupation?",
        occupation_text,
        target_speaker="user",
    )
    gift_answer = _extract_candidate_answer(
        "What did I buy for my sister's birthday gift?",
        gift_text,
        target_speaker="user",
    )
    pet_name_answer = _extract_candidate_answer(
        "What is the name of my cat?",
        pet_name_text,
        target_speaker="user",
    )
    brand_answer = _extract_candidate_answer(
        "What brand of shampoo do I currently use?",
        brand_text,
        target_speaker="user",
    )
    size_answer = _extract_candidate_answer(
        "What size is my new Samsung TV?",
        size_text,
        target_speaker="user",
    )
    ratio_answer = _extract_candidate_answer(
        "What is my preferred gin-to-vermouth ratio for a classic gin martini?",
        ratio_text,
        target_speaker="user",
    )
    relation_answer = _extract_candidate_answer(
        "Who did Maria have dinner with on May 3, 2023?",
        relation_text,
        target_speaker="maria",
    )
    movies_answer = _extract_candidate_answer(
        "What type of movies does Nate enjoy watching the most?",
        movies_text,
        target_speaker="nate",
    )
    fan_answer = _extract_candidate_answer(
        "Who is Melanie a fan of in terms of modern music?",
        fan_text,
        target_speaker="melanie",
    )
    support_answer = _extract_candidate_answer(
        "Who supports Caroline when she has a negative experience?",
        support_text,
        target_speaker="caroline",
    )

    assert longmem_answer["canonical_value"] == "Target"
    assert locomo_answer["canonical_value"].lower() == "yesterday"
    assert title_answer["canonical_value"] == "The Glass Menagerie"
    assert holiday_answer["canonical_value"] == "February 14th"
    assert game_answer["canonical_value"] == "Apex Legends"
    assert project_answer["canonical_value"] == "Finding Home"
    assert comparative_event_answer["canonical_value"] == "Michael's engagement party"
    assert comparative_person_answer["canonical_value"] == "Alex"
    assert occupation_answer["canonical_value"].lower() == "a marketing specialist at a small startup"
    assert gift_answer["canonical_value"].lower() == "a yellow dress"
    assert pet_name_answer["canonical_value"] == "Luna"
    assert brand_answer["canonical_value"] == "Trader Joe's"
    assert size_answer["canonical_value"].lower() == "55-inch"
    assert ratio_answer["canonical_value"] == "3:1"
    assert "mother" in relation_answer["canonical_value"].lower()
    assert movies_answer["canonical_value"].lower() == "action and sci-fi"
    assert fan_answer["canonical_value"] == "Ed Sheeran"
    assert "friends" in support_answer["canonical_value"].lower()
    assert float(longmem_answer["confidence"]) > 0.5


def test_locomo_relative_date_anchor_resolves_session_relative_answers():
    anchored_yesterday = _anchor_relative_date(
        candidate_text="yesterday",
        session_date="1:56 pm on 8 May, 2023",
        prompt="When did Caroline go to the LGBTQ support group?",
        source_text="Caroline: I went to a LGBTQ support group yesterday.",
    )
    anchored_last_year = _anchor_relative_date(
        candidate_text="last year",
        session_date="1:56 pm on 8 May, 2023",
        prompt="When did Melanie paint a sunrise?",
        source_text="Melanie: I painted a sunrise last year.",
    )
    anchored_next_month = _anchor_relative_date(
        candidate_text="next month",
        session_date="1:14 pm on 25 May, 2023",
        prompt="When will Caroline start the training?",
        source_text="Caroline: The training starts next month.",
    )
    anchored_last_week = _anchor_relative_date(
        candidate_text="last week",
        session_date="7:55 pm on 9 June, 2023",
        prompt="When did Caroline give a speech at a school?",
        source_text="Caroline: I gave a speech at a school last week.",
    )
    anchored_last_fri = _anchor_relative_date(
        candidate_text="last Fri",
        session_date="1:51 pm on 15 July, 2023",
        prompt="When did Melanie go to the pottery workshop?",
        source_text="Melanie: Last Fri I finally took my kids to a pottery workshop.",
    )

    assert anchored_yesterday is not None
    assert anchored_last_year is not None
    assert anchored_next_month is not None
    assert anchored_last_week is not None
    assert anchored_last_fri is not None
    assert anchored_yesterday["value"] == "7 May 2023"
    assert anchored_last_year["value"] == "2022"
    assert anchored_next_month["value"] == "June 2023"
    assert anchored_last_week["value"] == "The week before 9 June 2023"
    assert anchored_last_fri["value"] == "The Friday before 15 July 2023"
    assert _answer_matches(
        "When did Melanie go to the pottery workshop?",
        anchored_last_fri["value"],
        "The Friday before 15 July 2023",
    )


def test_direct_valid_prefers_focus_aligned_when_candidate():
    query = {
        "query_id": "q-when-focus",
        "query_text": "When did Caroline encounter people on a hike and have a negative experience?",
        "query_time": 1,
        "entity": "caroline",
        "slot": "answer",
        "stress_name": "external",
        "stress_value": 0.0,
        "query_lag": 0,
        "world_change_scale": 0.0,
        "write_error_rate": 0.0,
        "conflict_rate": 0.0,
        "distractor_overlap": 0.0,
    }
    candidate_rows = [
        {
            "memory_id": "m-correct",
            "score": 1.0,
            "text": "Caroline: I went hiking last week and got into a bad spot with some people.",
        },
        {
            "memory_id": "m-wrong",
            "score": 0.974896,
            "text": "Caroline: We had a blast last year at the Pride fest.",
        },
    ]
    pseudo_memories = [
        {
            "memory_id": "m-correct",
            "episode_id": "locomo:q-when-focus",
            "memory_text": candidate_rows[0]["text"],
            "entity": "caroline",
            "entity_alias": "caroline",
            "slot": "answer",
            "value_raw": "last week",
            "value_canonical": "The week before 25 August 2023",
            "write_time": 0,
            "source_id": "m-correct",
            "source_quality": 0.96,
            "stress_name": "external",
            "stress_value": 0.0,
            "write_correct": True,
            "candidate_answer_type": "when",
            "candidate_strategy": "date_pattern+date_anchor",
            "candidate_extraction_confidence": 0.95,
            "candidate_source_fragment": candidate_rows[0]["text"],
            "candidate_speaker": "caroline",
            "candidate_target_speaker": "caroline",
            "candidate_speaker_match": 1.0,
            "candidate_focus_score": 0.6625,
            "candidate_answer_type_match": 1.0,
            "candidate_query_reuse_ratio": 0.0,
            "candidate_novelty_score": 1.0,
            "candidate_date_alignment": None,
            "candidate_temporal_anchor": {"value": "The week before 25 August 2023"},
            "candidate_source_metadata": {},
        },
        {
            "memory_id": "m-wrong",
            "episode_id": "locomo:q-when-focus",
            "memory_text": candidate_rows[1]["text"],
            "entity": "caroline",
            "entity_alias": "caroline",
            "slot": "answer",
            "value_raw": "last year",
            "value_canonical": "2022",
            "write_time": 0,
            "source_id": "m-wrong",
            "source_quality": 0.96,
            "stress_name": "external",
            "stress_value": 0.0,
            "write_correct": True,
            "candidate_answer_type": "when",
            "candidate_strategy": "date_pattern+date_anchor",
            "candidate_extraction_confidence": 0.95,
            "candidate_source_fragment": candidate_rows[1]["text"],
            "candidate_speaker": "caroline",
            "candidate_target_speaker": "caroline",
            "candidate_speaker_match": 1.0,
            "candidate_focus_score": 0.2625,
            "candidate_answer_type_match": 1.0,
            "candidate_query_reuse_ratio": 0.0,
            "candidate_novelty_score": 1.0,
            "candidate_date_alignment": None,
            "candidate_temporal_anchor": {"value": "2022"},
            "candidate_source_metadata": {},
        },
    ]
    bundles = ExternalMethodBundles(
        relevance_bundle=_ConstantRelevanceBundle(),
        query_validity_bundles={"valid_label": _ConstantQueryValidityBundle()},
        anti_support_bundle=_ConstantAntiSupportBundle(),
        value_resolver_bundle=_FakeValueResolverBundle(),
    )

    predicted_answer, prior_scores, _components, _metadata = _run_external_learned_method(
        benchmark="locomo",
        method=DIRECT_VALID_METHOD,
        query=query,
        pseudo_memories=pseudo_memories,
        candidate_rows=candidate_rows,
        tfidf_lookup={"m-correct": 0.391434, "m-wrong": 1.0},
        bundles=bundles,
    )

    assert predicted_answer == "The week before 25 August 2023"
    assert prior_scores["The week before 25 August 2023"] > prior_scores["2022"]


def test_method_specific_judgment_adjustments_promote_negative_and_religious_votes():
    religious_scores, religious_metadata = _apply_method_specific_judgment_adjustments(
        query={"query_text": "Would Caroline be considered religious?"},
        pseudo_memories=[
            {
                "memory_id": "m-religious-self",
                "memory_text": (
                    "Caroline: This necklace is super special to me. "
                    "It has a cross on it and reminds me of home."
                ),
                "candidate_target_speaker": "caroline",
            },
            {
                "memory_id": "m-religious-other",
                "memory_text": "Caroline: I ran into a group of religious conservatives on a hike.",
                "candidate_target_speaker": "caroline",
            },
        ],
        prior_scores={"ran into": 0.9},
        retrieval_signal={"m-religious-self": 0.95, "m-religious-other": 1.0},
    )
    roadtrip_scores, roadtrip_metadata = _apply_method_specific_judgment_adjustments(
        query={"query_text": "Would Melanie go on another roadtrip soon?"},
        pseudo_memories=[
            {
                "memory_id": "m-roadtrip",
                "memory_text": (
                    "Melanie: That roadtrip this past weekend was insane. "
                    "My son got into an accident and it was a real scary experience."
                ),
                "candidate_target_speaker": "melanie",
            }
        ],
        prior_scores={"real support": 0.9},
        retrieval_signal={"m-roadtrip": 1.0},
    )
    career_scores, career_metadata = _apply_method_specific_judgment_adjustments(
        query={"query_text": "Was the first half of September 2022 a good month career-wise for Nate and Joanna? Answer yes or no."},
        pseudo_memories=[
            {
                "memory_id": "m-career",
                "memory_text": (
                    "Joanna: I got a rejection letter from a major company and it really bummed me out. "
                    "Nate: My tournament got pushed back."
                ),
                "candidate_target_speaker": "joanna",
            }
        ],
        prior_scores={"gameing career so I figured": 0.75, "no": 0.74},
        retrieval_signal={"m-career": 1.0},
    )

    assert religious_metadata is not None
    assert religious_scores["Somewhat religious"] > religious_scores["ran into"]
    assert roadtrip_metadata is not None
    assert roadtrip_scores["Likely no"] > roadtrip_scores["real support"]
    assert career_metadata is not None
    assert career_scores["No"] > career_scores["gameing career so I figured"]


def test_reasoning_adapter_handles_judgment_preference_and_activity_list():
    judgment_candidate = _build_reasoning_adapter_candidate(
        query_id="q-ally",
        prompt="Would Melanie be considered an ally to the transgender community?",
        candidate_rows=[
            {
                "memory_id": "m1",
                "score": 1.2,
                "text": (
                    "Melanie: Great to hear from you. I'm so proud of you for spreading awareness and "
                    "supporting the LGBTQ community."
                ),
            }
        ],
        pseudo_memories=[
            {
                "candidate_target_speaker": "melanie",
            }
        ],
    )
    preference_candidate = _build_reasoning_adapter_candidate(
        query_id="q-pref",
        prompt="Would Melanie be more interested in going to a national park or a theme park?",
        candidate_rows=[
            {
                "memory_id": "m2",
                "score": 1.0,
                "text": "Melanie: We loved camping, hiking, and spending time outdoors with the kids.",
            }
        ],
        pseudo_memories=[
            {
                "candidate_target_speaker": "melanie",
            }
        ],
    )
    activity_candidate = _build_reasoning_adapter_candidate(
        query_id="q-activities",
        prompt="What activities has Melanie done with her family?",
        candidate_rows=[
            {
                "memory_id": "m3",
                "score": 1.0,
                "text": "Melanie: We went camping and hiking together as a family last month.",
            },
            {
                "memory_id": "m4",
                "score": 0.8,
                "text": "Melanie: I also took the kids to the museum and went swimming with them.",
            },
        ],
        pseudo_memories=[
            {
                "candidate_target_speaker": "melanie",
            }
        ],
    )

    assert judgment_candidate is not None
    assert preference_candidate is not None
    assert activity_candidate is not None
    assert judgment_candidate["value"] == "Yes"
    assert preference_candidate["value"] == "national park"
    assert "camping" in activity_candidate["value"]
    assert "swimming" in activity_candidate["value"]


def test_singular_activity_prompts_extract_specific_answers_and_skip_list_adapter():
    horseback_text = (
        "Caroline: That's so funny! I used to go horseback riding with my dad when I was a kid, "
        "we'd go through the fields, feeling the wind."
    )
    camping_text = (
        "John: Thanks, Maria! Max and I had a blast on our camping trip last summer. "
        "We hiked, swam, and made great memories."
    )
    watercolor_text = (
        "Evan: I do my favorite watercolor painting to keep me busy. "
        "It's a chill way to relax and get into the colors."
    )
    lifting_text = (
        "Evan: I started lifting weights one year ago and it's been a journey. "
        "It was a struggle at first, but I'm seeing some gains."
    )
    yoga_text = (
        "Evan: Yeah, I've been thinking about trying yoga, "
        "something gentle yet effective for stress relief and flexibility."
    )

    horseback_answer = _extract_candidate_answer(
        "What activity did Caroline used to do with her dad?",
        horseback_text,
        target_speaker="caroline",
    )
    camping_answer = _extract_candidate_answer(
        "What activity did John and Max enjoy together last summer?",
        camping_text,
        target_speaker="john",
    )
    watercolor_answer = _extract_candidate_answer(
        "What activity does Evan do to keep himself busy while healing his knee?",
        watercolor_text,
        target_speaker="evan",
    )
    lifting_answer = _extract_candidate_answer(
        "What activity did Evan start one year ago?",
        lifting_text,
        target_speaker="evan",
    )
    yoga_answer = _extract_candidate_answer(
        "What activity helped Evan with stress and flexibility?",
        yoga_text,
        target_speaker="evan",
    )
    singular_adapter = _build_reasoning_adapter_candidate(
        query_id="q-singular-activity",
        prompt="What activity did John and Max enjoy together last summer?",
        candidate_rows=[
            {
                "memory_id": "m-camping",
                "score": 1.0,
                "text": camping_text,
            },
            {
                "memory_id": "m-hiking",
                "score": 0.9,
                "text": "John: We also went hiking together in the fall and enjoyed the trails.",
            },
        ],
        pseudo_memories=[
            {
                "candidate_target_speaker": "john",
            }
        ],
    )

    assert horseback_answer["canonical_value"].lower() == "horseback riding"
    assert camping_answer["canonical_value"].lower() == "camping"
    assert watercolor_answer["canonical_value"].lower() == "watercolor painting"
    assert lifting_answer["canonical_value"].lower() == "lifting weights"
    assert yoga_answer["canonical_value"].lower() == "yoga"
    assert singular_adapter is None


def test_prompt_choice_extraction_and_adapter_handle_choice_like_judgment_prompts():
    assert _is_comparative_prompt("Does John live close to a beach or the mountains?")
    assert _extract_prompt_choice_candidates(
        "Does John live close to a beach or the mountains?",
        "judgment",
    ) == ["beach", "mountains"]
    assert _extract_prompt_choice_candidates(
        "Would Tim enjoy reading books by C. S. Lewis or John Greene?",
        "judgment",
    ) == ["C. S. Lewis", "John Greene"]
    assert _extract_prompt_choice_candidates(
        "Which pet did Jolene adopt more recently - Susie or Seraphim?",
        "generic",
    ) == ["Susie", "Seraphim"]

    beach_candidate = _build_reasoning_adapter_candidate(
        query_id="q-beach",
        prompt="Does John live close to a beach or the mountains?",
        candidate_rows=[
            {
                "memory_id": "m-beach",
                "score": 1.0,
                "text": "John: Living near the beach lets me walk along the coast and spend time by the ocean whenever I can.",
            },
            {
                "memory_id": "m-mountain",
                "score": 0.6,
                "text": "John: Hiking in the mountains sounds nice once in a while, but I rarely get there.",
            },
        ],
        pseudo_memories=[
            {
                "candidate_target_speaker": "john",
            }
        ],
    )
    author_candidate = _build_reasoning_adapter_candidate(
        query_id="q-author",
        prompt="Would Tim enjoy reading books by C. S. Lewis or John Greene?",
        candidate_rows=[
            {
                "memory_id": "m-author",
                "score": 1.0,
                "text": "Tim: I've always loved fantasy novels with magical worlds, myth, and adventurous stories.",
            }
        ],
        pseudo_memories=[
            {
                "candidate_target_speaker": "tim",
            }
        ],
    )
    pet_candidate = _build_reasoning_adapter_candidate(
        query_id="q-pet",
        prompt="Which pet did Jolene adopt more recently - Susie or Seraphim?",
        candidate_rows=[
            {
                "memory_id": "m-seraphim",
                "score": 1.0,
                "text": "Jolene: My second snake Seraphim finally relaxed after I brought her home.",
            },
            {
                "memory_id": "m-susie",
                "score": 0.7,
                "text": "Jolene: Susie was my first snake years ago.",
            },
        ],
        pseudo_memories=[
            {
                "candidate_target_speaker": "jolene",
            }
        ],
    )

    assert beach_candidate is not None
    assert beach_candidate["value"] == "beach"
    assert author_candidate is not None
    assert author_candidate["value"] == "C. S. Lewis"
    assert pet_candidate is not None
    assert pet_candidate["value"] == "Seraphim"


def test_non_choice_or_list_prompts_do_not_trigger_prompt_choice_extraction():
    assert not _is_comparative_prompt("Which places or events has Calvin visited in Tokyo?")
    assert _extract_prompt_choice_candidates(
        "Which places or events has Calvin visited in Tokyo?",
        "event_name",
    ) == []
    assert _extract_prompt_choice_candidates(
        "Who or which organizations have been the beneficiaries of John's charity tournaments?",
        "person_name",
    ) == []


def test_where_reasoning_adapter_prefers_direct_destinations_and_location_lists():
    woodhaven_candidate = _build_reasoning_adapter_candidate(
        query_id="q-woodhaven",
        prompt="Where did Joanna travel to in July 2022?",
        candidate_rows=[
            {
                "memory_id": "m-woodhaven",
                "score": 1.0,
                "text": (
                    "Joanna: I went to Woodhaven, a small town in the Midwest. "
                    "Got to see some lovely scenery and historic buildings."
                ),
            }
        ],
        pseudo_memories=[
            {
                "candidate_target_speaker": "joanna",
            }
        ],
    )
    friends_candidate = _build_reasoning_adapter_candidate(
        query_id="q-friends",
        prompt="Where has Maria made friends?",
        candidate_rows=[
            {
                "memory_id": "m-shelter",
                "score": 1.0,
                "text": "Maria: I've been volunteering at a homeless shelter and met some amazing people there.",
            },
            {
                "memory_id": "m-gym",
                "score": 0.95,
                "text": "Maria: I joined a gym last week and the people there are awesome and welcoming.",
            },
            {
                "memory_id": "m-church",
                "score": 0.9,
                "text": "Maria: Some friends from church and I went camping last weekend and really connected.",
            },
        ],
        pseudo_memories=[
            {
                "candidate_target_speaker": "maria",
            }
        ],
    )
    country_candidate = _build_reasoning_adapter_candidate(
        query_id="q-country",
        prompt="In what country did Jolene's mother buy her the pendant?",
        candidate_rows=[
            {
                "memory_id": "m-paris",
                "score": 1.0,
                "text": "Jolene: My mother gave me the pendant in 2010 in Paris.",
            },
            {
                "memory_id": "m-beach",
                "score": 0.98,
                "text": "Jolene: Is yoga on the beach a thing? It sounds relaxing.",
            },
        ],
        pseudo_memories=[
            {
                "candidate_target_speaker": "jolene",
            }
        ],
    )
    frequent_country_candidate = _build_reasoning_adapter_candidate(
        query_id="q-frequent-country",
        prompt="which country has Tim visited most frequently in his travels?",
        candidate_rows=[
            {
                "memory_id": "m-uk-1",
                "score": 1.0,
                "text": "Tim: I read about castles in the UK and want to visit them.",
            },
            {
                "memory_id": "m-uk-2",
                "score": 0.95,
                "text": "Tim: I went to a castle during my trip to the UK last Friday.",
            },
            {
                "memory_id": "m-ireland",
                "score": 0.9,
                "text": "Tim: I'm off to Ireland for a semester, staying in Galway near the Cliffs of Moher.",
            },
        ],
        pseudo_memories=[
            {
                "candidate_target_speaker": "tim",
            }
        ],
    )
    open_space_prompt = "Where does Andrew want to live to give their dog a large, open space to run around?"
    sweden_answer = _extract_candidate_answer(
        "Where did Caroline move from 4 years ago?",
        "Caroline: This necklace is special to me - a gift from my grandma in my home country, Sweden.",
        target_speaker="caroline",
    )

    assert woodhaven_candidate is not None
    assert woodhaven_candidate["value"] == "Woodhaven"
    assert friends_candidate is not None
    assert "homeless shelter" in friends_candidate["value"]
    assert "gym" in friends_candidate["value"]
    assert "church" in friends_candidate["value"]
    assert country_candidate is not None
    assert country_candidate["value"] == "France"
    assert frequent_country_candidate is not None
    assert frequent_country_candidate["value"] == "UK"
    assert _prompt_family_candidate_bonus(open_space_prompt, "park or woods", "near a park or woods", "location_pattern") > 1.0
    assert _prompt_family_candidate_bonus(open_space_prompt, "city", "living in the city", "reasoning_where") < -1.0
    assert sweden_answer["value"] == "Sweden"


def test_reasoning_adapter_handles_list_source_venue_photoshoot_and_temporal_choice_prompts():
    place_event_candidate = _build_reasoning_adapter_candidate(
        query_id="q-places-events",
        prompt="Which places or events have John and James planned to meet at?",
        candidate_rows=[
            {
                "memory_id": "m-meet-1",
                "score": 1.0,
                "text": "James: Samantha and I were also at McGee's bar. We are going to a baseball game next Sunday.",
            },
            {
                "memory_id": "m-meet-2",
                "score": 0.8,
                "text": "James: We had a fun date night at VR Club and want to go back there soon.",
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "james"}],
    )
    beneficiary_candidate = _build_reasoning_adapter_candidate(
        query_id="q-beneficiaries",
        prompt="Who or which organizations have been the beneficiaries of John's charity tournaments?",
        candidate_rows=[
            {
                "memory_id": "m-benefit-1",
                "score": 1.0,
                "text": "John: We raised money for a dog shelter and used the rest to cook food for the homeless.",
            },
            {
                "memory_id": "m-benefit-2",
                "score": 0.9,
                "text": "John: Last night we held another gaming tourney and raised money for a children's hospital.",
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "john"}],
    )
    idea_candidate = _build_reasoning_adapter_candidate(
        query_id="q-idea-from",
        prompt="Where did Maria get the idea for the castle shadow box in her home?",
        candidate_rows=[
            {
                "memory_id": "m-idea",
                "score": 1.0,
                "text": "Maria: I got the idea from that trip to England a few years ago - I was mesmerized by the castles.",
            },
            {
                "memory_id": "m-shelter",
                "score": 0.95,
                "text": "Maria: I've been volunteering at a homeless shelter and it's been meaningful.",
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "maria"}],
    )
    venue_candidate = _build_reasoning_adapter_candidate(
        query_id="q-venue",
        prompt="What type of venue did John and his girlfriend choose for their wedding ceremony?",
        candidate_rows=[
            {
                "memory_id": "m-venue",
                "score": 1.0,
                "text": "John: We were lucky to find a lovely greenhouse venue for a smaller, more intimate gathering.",
            }
        ],
        pseudo_memories=[{"candidate_target_speaker": "john"}],
    )
    photoshoot_candidate = _build_reasoning_adapter_candidate(
        query_id="q-photoshoot",
        prompt="Where was the photoshoot done for John's gear deal?",
        candidate_rows=[
            {
                "memory_id": "m-photoshoot",
                "score": 1.0,
                "text": "John: The photoshoot went really well too. We did it in a gorgeous forest and the photographer got some epic shots.",
            }
        ],
        pseudo_memories=[{"candidate_target_speaker": "john"}],
    )
    first_pet_candidate = _build_reasoning_adapter_candidate(
        query_id="q-first-pet",
        prompt="Which pet did Jolene adopt first - Susie or Seraphim?",
        candidate_rows=[
            {
                "memory_id": "m-susie",
                "score": 1.0,
                "text": "Jolene: I adopted Susie two years ago when I was feeling lonely and wanted some company.",
            },
            {
                "memory_id": "m-seraphim-recent",
                "score": 0.9,
                "text": "Jolene: I got Seraphim last year and she's a great pet.",
            },
            {
                "memory_id": "m-seraphim-park",
                "score": 0.95,
                "text": "Jolene: I took Seraphim to the park last Sunday and she loved it.",
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "jolene"}],
    )

    assert place_event_candidate is not None
    assert "McGee's" in place_event_candidate["value"]
    assert "baseball game" in place_event_candidate["value"]
    assert beneficiary_candidate is not None
    assert "animal shelter" in beneficiary_candidate["value"]
    assert "children's hospital" in beneficiary_candidate["value"]
    assert "homeless" in beneficiary_candidate["value"]
    assert idea_candidate is not None
    assert idea_candidate["value"] == "England"
    assert venue_candidate is not None
    assert venue_candidate["value"] == "greenhouse"
    assert photoshoot_candidate is not None
    assert "forest" in photoshoot_candidate["value"].lower()
    assert first_pet_candidate is not None
    assert first_pet_candidate["value"] == "Susie"


def test_local_prompt_extractors_handle_books_workout_and_food_spread():
    books_answer = _extract_candidate_answer(
        "What kind of books does Caroline have in her library?",
        (
            "Caroline: Being a mom is awesome. I'm creating a library for when I have kids. "
            "Melanie: Sounds great! What kind of books you got in your library? "
            "Caroline: I've got lots of kids' books- classics, stories from different cultures, "
            "educational books, all of that."
        ),
        target_speaker="caroline",
    )
    workout_answer = _extract_candidate_answer(
        "What type of workout class did Maria start doing in December 2023?",
        (
            "Maria: Been busy volunteering at the homeless shelter and keeping fit. "
            "Just started doing aerial yoga, it's great. "
            "Have you tried any other cool workout classes?"
        ),
        target_speaker="maria",
    )
    food_answer = _extract_candidate_answer(
        "What kind of food did Maria have on her dinner spread iwth her mother?",
        (
            "Maria: My mom and I made some dinner together last night! "
            "John: What do you have in this spread? Looks delicious! "
            "Maria: Thanks, John! It had lots of great things like salads, sandwiches, "
            "and homemade desserts. My favorite is the amazing banana split sundae."
        ),
        target_speaker="maria",
    )
    noise_instrument_answer = _extract_candidate_answer(
        "What instruments does Melanie play?",
        "Melanie: Clay is incredible, it brings me so much joy!",
        target_speaker="melanie",
    )

    assert books_answer["canonical_value"] == "kids' books - classics, stories from different cultures, educational books"
    assert workout_answer["canonical_value"].lower() == "aerial yoga"
    assert food_answer["canonical_value"].lower() == "salads, sandwiches, homemade desserts"
    assert noise_instrument_answer["canonical_value"] == ""


def test_local_prompt_extractors_handle_pet_book_and_music_title_lists():
    snake_answer = _extract_candidate_answer(
        "What are the names of Jolene's snakes?",
        (
            "Jolene: I want to show you one of my snakes! This is Susie. "
            "Deborah: Having a pet totally brightens up your life. "
            "Jolene: My second snake Seraphim did it. Look at her sly eyes!"
        ),
        target_speaker="jolene",
    )
    books_answer = _extract_candidate_answer(
        "What are Jolene's favorite books?",
        (
            "Jolene: Thanks Deborah! I'm really into this book called \"Sapiens\" - "
            "it's a fascinating look at human history. "
            "Jolene: Two weeks ago I read \"Avalanche\" by Neal Stephenson in one sitting!"
        ),
        target_speaker="jolene",
    )
    music_answer = _extract_candidate_answer(
        "What music pieces does Deborah listen to during her yoga practice?",
        (
            "Deborah: I find instrumental tracks with mellow melodies and rhythms help create a peaceful vibe. "
            "One of my favorites is a track called \"Savana.\" "
            "Deborah: Also, I'm listening to an album called 'Sleep,' which is great for meditation and deep relaxation."
        ),
        target_speaker="deborah",
    )

    assert _infer_answer_type("What are the names of Jolene's snakes?") == "pet_name"
    assert _infer_answer_type("What music pieces does Deborah listen to during her yoga practice?") == "title_or_name"
    assert snake_answer["canonical_value"] == "Susie, Seraphim"
    assert books_answer["canonical_value"] == "Sapiens, Avalanche by Neal Stephenson"
    assert music_answer["canonical_value"] == "Savana, Sleep"
    assert _answer_matches(
        "What are the names of Jolene's snakes?",
        snake_answer["canonical_value"],
        "Susie, Seraphim",
    )
    assert _answer_matches(
        "What are Jolene's favorite books?",
        books_answer["canonical_value"],
        "Sapiens, Avalanche by Neal Stephenson",
    )
    assert _answer_matches(
        "What music pieces does Deborah listen to during her yoga practice?",
        music_answer["canonical_value"],
        "Savana, Sleep",
    )


def test_local_prompt_extractors_handle_activity_edge_cases():
    dinner_answer = _extract_candidate_answer(
        "What activity did Maria and her mom do together in May 2023?",
        "Maria: My mom and I made some dinner together last night! It turned out great.",
        target_speaker="maria",
    )
    travel_answer = _extract_candidate_answer(
        "What activity did Tim do after reading the stories about the Himalayan trek?",
        "Tim: After reading those stories, I visited a travel agency to start planning my own trek.",
        target_speaker="tim",
    )
    conference_answer = _extract_candidate_answer(
        "What did Jolene participate in recently that provided her with a rewarding experience?",
        "Jolene: Presenting at a virtual conference was such a rewarding experience for me.",
        target_speaker="jolene",
    )
    festival_answer = _extract_candidate_answer(
        "What activity did Deborah enjoy at the music festival with their pals on September 20, 2023?",
        "Deborah: I had a great time at the music festival with my pals, dancing and bopping around.",
        target_speaker="deborah",
    )
    dog_park_answer = _extract_candidate_answer(
        "What activity do Audrey's dogs like to do in the dog park?",
        "Audrey: My dogs like to play fetch with ball and frisbee and run around and meet other dogs at the dog park.",
        target_speaker="audrey",
    )

    assert dinner_answer["canonical_value"] == "made dinner together"
    assert travel_answer["canonical_value"] == "visited a travel agency"
    assert conference_answer["canonical_value"] == "presenting at a virtual conference"
    assert festival_answer["canonical_value"] == "dancing and bopping around"
    assert _answer_contains_gold(
        dog_park_answer["canonical_value"],
        "Play fetch with ball and frisbee, run around and meet other dogs",
    )


def test_local_prompt_extractors_handle_item_edge_cases():
    instrument_answer = _extract_candidate_answer(
        "What instruments does Tim play?",
        "Tim: I play the violin and the piano whenever I need to unwind.",
        target_speaker="tim",
    )
    pastry_answer = _extract_candidate_answer(
        "What kind of pastries did Andrew and his girlfriend have at the cafe?",
        "Andrew: We found an awesome cafe with amazing pastries like croissants, muffins, and tarts.",
        target_speaker="andrew",
    )
    music_answer = _extract_candidate_answer(
        "What kind of music does John like?",
        "John: I'm into electronic and rock music.",
        target_speaker="john",
    )
    car_answer = _extract_candidate_answer(
        "What type of car did Dave work on during the workshop?",
        "Dave: I finally got to work on a classic muscle car at the workshop.",
        target_speaker="dave",
    )
    musician_answer = _extract_candidate_answer(
        "Who are the musicians mentioned by Jolene that she enjoys listening to during her yoga practice?",
        "Jolene: I love listening to Nils Frahm and Olafur Arnalds during my practice.",
        target_speaker="jolene",
    )
    childhood_artist_answer = _extract_candidate_answer(
        "What was the artists Calvin used to listen to when he was a kid?",
        "Calvin: We used to rock a song by Tupac and Dr. Dre called \"California Love\".",
        target_speaker="calvin",
    )
    band_answer = _extract_candidate_answer(
        "Which band was Dave's favorite at the music festival in April 2023?",
        "Dave: There were so many great bands. If I had to pick a favorite, it would definitely be Aerosmith.",
        target_speaker="dave",
    )
    performer_answer = _extract_candidate_answer(
        "Who performed at the concert at Melanie's daughter's birthday?",
        "Melanie: It was Matt Patterson, he is so talented!",
        target_speaker="melanie",
    )
    modern_music_answer = _extract_candidate_answer(
        "Who is Melanie a fan of in terms of modern music?",
        "Melanie: I'm a fan of classical music, as well as modern music like Ed Sheeran's \"Perfect\".",
        target_speaker="melanie",
    )

    assert "violin" in instrument_answer["canonical_value"].lower()
    assert "piano" in instrument_answer["canonical_value"].lower()
    assert "croissants" in pastry_answer["canonical_value"].lower()
    assert "muffins" in pastry_answer["canonical_value"].lower()
    assert "tarts" in pastry_answer["canonical_value"].lower()
    assert _answer_matches(
        "What kind of pastries did Andrew and his girlfriend have at the cafe?",
        pastry_answer["canonical_value"],
        "croissants, muffins, and tarts",
    )
    assert music_answer["canonical_value"].lower() == "electronic and rock music"
    assert car_answer["canonical_value"].lower() == "classic muscle car"
    assert musician_answer["canonical_value"] == "Nils Frahm and Olafur Arnalds"
    assert childhood_artist_answer["canonical_value"] == "Tupac and Dr. Dre"
    assert band_answer["canonical_value"] == "Aerosmith"
    assert performer_answer["canonical_value"] == "Matt Patterson"
    assert modern_music_answer["canonical_value"] == "Ed Sheeran"


def test_pet_name_extractor_prefers_actual_pet_naming_clauses():
    answer = _extract_candidate_answer(
        "What is the name of Maria's puppy?",
        (
            "Maria: Guess what - I got a puppy two weeks ago! Her name's Coco and she's adorable.\n"
            "John: Wow, Maria! Coco looks so adorable!\n"
            "Maria: Yeah, at the event, I had a conversation with someone named David.\n"
            "Maria: Her name is Shadow!\n"
        ),
        target_speaker="maria",
    )

    assert answer["canonical_value"] == "Coco"


def test_pet_name_extractor_handles_grief_clauses_as_clean_names():
    answer = _extract_candidate_answer(
        "What was the name of the pet that John had to say goodbye to on 3 June, 2023?",
        (
            "John: The toughest thing to deal with is that we had to say goodbye to Max.\n"
            "Maria: I'm so sorry, John. Losing a pet hurts.\n"
        ),
        target_speaker="john",
    )

    assert answer["canonical_value"] == "Max"
    assert _answer_matches(
        "What was the name of the pet that John had to say goodbye to on 3 June, 2023?",
        answer["canonical_value"],
        "Max",
    )


def test_reasoning_adapter_aggregates_prompt_specific_lists():
    pottery_candidate = _build_reasoning_adapter_candidate(
        query_id="q-pottery-items",
        prompt="What types of pottery have Melanie and her kids made?",
        candidate_rows=[
            {
                "memory_id": "m-pottery-main",
                "score": 1.0,
                "text": (
                    "Melanie: Last Fri I finally took my kids to a pottery workshop. "
                    "We all made our own pots, it was fun and therapeutic!\n"
                    "[image_caption] a photo of a cup with a dog face on it\n"
                    "Melanie: What do you think of these?\n"
                    "[image_caption] a photo of a blue vase with a bouquet of sunflowers and roses"
                ),
            },
            {
                "memory_id": "m-pottery-bowl",
                "score": 0.86,
                "text": "Melanie: Thanks, Caroline! Yeah, I made this bowl in my class. It took some work.",
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "melanie"}],
    )
    instrument_candidate = _build_reasoning_adapter_candidate(
        query_id="q-instruments",
        prompt="What instruments does Melanie play?",
        candidate_rows=[
            {
                "memory_id": "m-violin",
                "score": 1.0,
                "text": "Melanie: I'm carving out some me-time each day - running, reading, or playing my violin.",
            },
            {
                "memory_id": "m-clarinet",
                "score": 0.91,
                "text": "Melanie: Yeah, I play clarinet! Started when I was young and it's been great.",
            },
            {
                "memory_id": "m-noise-clay",
                "score": 0.98,
                "text": "Melanie: Clay is incredible, it brings me so much joy!",
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "melanie"}],
    )
    shelter_candidate = _build_reasoning_adapter_candidate(
        query_id="q-shelters",
        prompt="What shelters does Maria volunteer at?",
        candidate_rows=[
            {
                "memory_id": "m-homeless",
                "score": 1.0,
                "text": "Maria: I donated my old car to a homeless shelter I volunteer at yesterday.",
            },
            {
                "memory_id": "m-dog",
                "score": 0.93,
                "text": "Maria: I just started volunteering at a local dog shelter once a month.",
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "maria"}],
    )
    food_candidate = _build_reasoning_adapter_candidate(
        query_id="q-food-spread",
        prompt="What kind of food did Maria have on her dinner spread iwth her mother?",
        candidate_rows=[
            {
                "memory_id": "m-food",
                "score": 0.82,
                "text": (
                    "Maria: My mom and I made some dinner together last night! "
                    "It had lots of great things like salads, sandwiches, and homemade desserts. "
                    "My favorite is the amazing banana split sundae."
                ),
            },
            {
                "memory_id": "m-noise",
                "score": 1.0,
                "text": "Maria: If you know anyone who might be interested in volunteering for the event, let me know.",
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "maria"}],
    )

    assert pottery_candidate is not None
    assert pottery_candidate["strategy"] == "reasoning_pottery_items"
    assert _answer_contains_gold(pottery_candidate["value"], "bowls, cup")
    assert "vase" not in pottery_candidate["value"].lower()
    assert instrument_candidate is not None
    assert instrument_candidate["strategy"] == "reasoning_instrument_list"
    assert _answer_contains_gold(instrument_candidate["value"], "clarinet and violin")
    assert shelter_candidate is not None
    assert shelter_candidate["strategy"] == "reasoning_shelter_list"
    assert _answer_contains_gold(shelter_candidate["value"], "The homeless shelter, the dog shelter")
    assert food_candidate is not None
    assert food_candidate["strategy"] == "reasoning_food_spread"
    assert _answer_contains_gold(food_candidate["value"], "Salads, sandwiches, homemade desserts")


def test_reasoning_adapter_handles_like_and_painted_prompt_lists():
    like_candidate = _build_reasoning_adapter_candidate(
        query_id="q-kids-like",
        prompt="What do Melanie's kids like?",
        candidate_rows=[
            {
                "memory_id": "m-nature",
                "score": 0.85,
                "text": "Melanie: The 2 younger kids love nature. It was so special having these moments together as a family.",
            },
            {
                "memory_id": "m-dinosaurs",
                "score": 0.92,
                "text": "Melanie: They were stoked for the dinosaur exhibit! They love learning about animals and the bones were so cool.",
            },
            {
                "memory_id": "m-noise",
                "score": 1.0,
                "text": "Melanie: You guys like doing everything together, huh?",
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "melanie"}],
    )
    painted_candidate = _build_reasoning_adapter_candidate(
        query_id="q-painted-items",
        prompt="What has Melanie painted?",
        candidate_rows=[
            {
                "memory_id": "m-sunrise",
                "score": 1.0,
                "text": "Melanie: Yeah, I painted that lake sunrise last year! It's special to me.",
            },
            {
                "memory_id": "m-horse",
                "score": 0.91,
                "text": "Melanie: Here's a photo of my horse painting I did recently.",
            },
            {
                "memory_id": "m-sunset",
                "score": 0.88,
                "text": (
                    "Melanie: We love painting together lately.\n"
                    "[image_caption] a photo of a painting of a sunset with a palm tree"
                ),
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "melanie"}],
    )

    assert like_candidate is not None
    assert like_candidate["strategy"] == "reasoning_like_items"
    assert _answer_contains_gold(like_candidate["value"], "dinosaurs, nature")
    assert painted_candidate is not None
    assert painted_candidate["strategy"] == "reasoning_painted_items"
    assert _answer_contains_gold(painted_candidate["value"], "Horse, sunset, sunrise")


def test_painted_prompt_extractor_handles_caption_subjects():
    text = (
        "Melanie: Yeah, I painted that lake sunrise last year! It's special to me.\n"
        "[image_caption] a photo of a painting of a sunset over the ocean\n"
        "Melanie: Nature's amazing, here's a painting I did recently.\n"
        "[image_caption] a photo of a stained glass window with a picture of a person on a horse\n"
    )

    normalized = {
        _normalize_painted_prompt_item(item)
        for item in _extract_painted_prompt_items(text)
        if _normalize_painted_prompt_item(item)
    }

    assert {"sunrise", "sunset", "horse"} <= normalized


def test_local_prompt_extractors_handle_generic_relation_prompts():
    painted_answer = _extract_candidate_answer(
        "What has Melanie painted?",
        (
            "Melanie: Yeah, I painted that lake sunrise last year! It's special to me.\n"
            "[image_caption] a photo of a painting of a sunset over the ocean\n"
            "Melanie: Nature's amazing, here's a painting I did recently.\n"
            "[image_caption] a photo of a stained glass window with a picture of a person on a horse\n"
        ),
        target_speaker="melanie",
    )
    self_care_answer = _extract_candidate_answer(
        "How does Melanie prioritize self-care?",
        (
            "Melanie: I'm starting to realize that self-care is really important. "
            "So I'm carving out some me-time each day - running, reading, or playing my violin - "
            "which refreshes me and helps me stay present for my fam!"
        ),
        target_speaker="melanie",
    )
    excited_answer = _extract_candidate_answer(
        "What is Caroline excited about in the adoption process?",
        (
            "Caroline: Researching adoption agencies - it's been a dream to have a family and give a loving home to kids who need it. "
            "Caroline: I'm thrilled to make a family for kids who need one. It'll be tough as a single parent, but I'm up for the challenge!"
        ),
        target_speaker="caroline",
    )
    judgment_answer = _extract_candidate_answer(
        "What does Melanie think about Caroline's decision to adopt?",
        (
            "Melanie: You're doing something amazing! Creating a family for those kids is so lovely. "
            "You'll be an awesome mom!"
        ),
        target_speaker="melanie",
    )
    motivation_answer = _extract_candidate_answer(
        "What motivated Caroline to pursue counseling?",
        (
            "Caroline: My own journey and the support I got made a huge difference. "
            "I saw how counseling and support groups improved my life, so I started caring more about mental health."
        ),
        target_speaker="caroline",
    )
    great_for_answer = _extract_candidate_answer(
        "What does Melanie say running has been great for?",
        (
            "Melanie: These are for running. Been running longer since our last chat - a great way to destress and clear my mind. "
            "I've been running farther to de-stress, which has been great for my headspace. "
            "This has been great for my mental health."
        ),
        target_speaker="melanie",
    )
    advice_answer = _extract_candidate_answer(
        "What advice does Caroline give for getting started with adoption?",
        (
            "Caroline: Yep! Do your research and find an adoption agency or lawyer. "
            "They'll help with the process and provide all the info. "
            "Gather documents like references, financial info and medical checks. "
            "Don't forget to prepare emotionally, since the wait can be hard."
        ),
        target_speaker="caroline",
    )
    made_for_answer = _extract_candidate_answer(
        "What did Caroline make for a local church?",
        (
            "Caroline: Thanks, Mel! I made this stained glass window to remind myself and others that within us all is the key "
            "to discovering our true potential and living our best life. "
            "It was made for a local church and shows time changing our lives."
        ),
        target_speaker="caroline",
    )
    importance_answer = _extract_candidate_answer(
        "Why are flowers important to Melanie?",
        (
            "Melanie: Flowers bring joy. They represent growth, beauty and reminding us to appreciate the small moments. "
            "They were an important part of my wedding decor and always remind me of that day."
        ),
        target_speaker="melanie",
    )

    assert _answer_contains_gold(painted_answer["canonical_value"], "Horse, sunset, sunrise")
    assert "running, reading" in self_care_answer["canonical_value"].lower()
    assert "violin" in self_care_answer["canonical_value"].lower()
    assert "family for kids who need one" in excited_answer["canonical_value"].lower()
    assert "doing something amazing" in judgment_answer["canonical_value"].lower()
    assert "awesome mother" in judgment_answer["canonical_value"].lower() or "awesome mom" in judgment_answer["canonical_value"].lower()
    assert "journey" in motivation_answer["canonical_value"].lower()
    assert "support received" in motivation_answer["canonical_value"].lower()
    assert "mental health" in great_for_answer["canonical_value"].lower()
    assert "adoption agency or lawyer" in advice_answer["canonical_value"].lower()
    assert "prepare emotionally" in advice_answer["canonical_value"].lower()
    assert made_for_answer["canonical_value"].lower() == "a stained glass window"
    assert "small moments" in importance_answer["canonical_value"].lower()
    assert "wedding decor" in importance_answer["canonical_value"].lower()


def test_strict_local_prompt_families_avoid_noisy_fallbacks():
    empty_made_for = _extract_candidate_answer(
        "What did Caroline make for a local church?",
        "Caroline: It's taken a while to get here, but I'm finally proud of who I am.",
        target_speaker="caroline",
    )
    empty_judgment = _extract_candidate_answer(
        "What does Melanie think about Caroline's decision to adopt?",
        "Melanie: You're so strong and inspiring.",
        target_speaker="melanie",
    )

    assert empty_made_for["canonical_value"] == ""
    assert empty_made_for["strategy"] == "no_explicit_made_for_candidate"
    assert empty_judgment["canonical_value"] == ""
    assert empty_judgment["strategy"] == "no_explicit_supportive_judgment_candidate"


def test_answer_matches_motivation_summary_triad():
    assert _answer_matches(
        "What motivated Caroline to pursue counseling?",
        "own journey, support received, and how counseling improved her life",
        "her own journey and the support she received, and how counseling improved her life",
    )


def test_answer_matches_supportive_adoption_judgment_summary():
    assert _answer_matches(
        "What does Melanie think about Caroline's decision to adopt?",
        "doing something amazing and will be an awesome mother",
        "she thinks Caroline is doing something amazing and will be an awesome mom",
    )


def test_reasoning_adapter_handles_realistic_idea_sources_and_adopt_first_failures():
    castle_idea_candidate = _build_reasoning_adapter_candidate(
        query_id="q-castle-idea-realistic",
        prompt="Where did Maria get the idea for the castle shadow box in her home?",
        candidate_rows=[
            {
                "memory_id": "m-shelter-noise",
                "score": 1.0,
                "text": (
                    "Maria: I started volunteering here about a year ago after witnessing a family struggling on the streets. "
                    "It made me want to help, so I reached out to the shelter and asked if they needed any volunteers."
                ),
            },
            {
                "memory_id": "m-england-idea",
                "score": 0.85,
                "text": (
                    "Maria: Thanks, John! I got the idea from that trip to England a few years ago - "
                    "I was mesmerized by the castles."
                ),
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "maria"}],
    )
    character_idea_candidate = _build_reasoning_adapter_candidate(
        query_id="q-character-idea-realistic",
        prompt="Where does Joanna get her ideas for the characters from?",
        candidate_rows=[
            {
                "memory_id": "m-joanna-ideas",
                "score": 1.0,
                "text": (
                    "Joanna: I got ideas from everywhere: people I know, stuff I saw, even what I imagined. "
                    "It's cool to see how an idea takes shape."
                ),
            }
        ],
        pseudo_memories=[{"candidate_target_speaker": "joanna"}],
    )
    realistic_first_pet_candidate = _build_reasoning_adapter_candidate(
        query_id="q-first-pet-realistic",
        prompt="Which pet did Jolene adopt first - Susie or Seraphim?",
        candidate_rows=[
            {
                "memory_id": "m-susie-support",
                "score": 1.0,
                "text": (
                    "Jolene: Susie really helps when times get tough. "
                    "I adopted her two years ago when I was feeling lonely and wanted some company."
                ),
            },
            {
                "memory_id": "m-seraphim-recent",
                "score": 0.9,
                "text": (
                    "Jolene: Here are new photos of Seraphim in the new aquarium that I bought the day before yesterday. "
                    "I got her last year, she's a great pet."
                ),
            },
            {
                "memory_id": "m-seraphim-noisy",
                "score": 0.95,
                "text": (
                    "Jolene: I've got a lot going on with my studies and exams. "
                    "I did take Seraphim to the park last Sunday and she loved it."
                ),
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "jolene"}],
    )

    assert castle_idea_candidate is not None
    assert castle_idea_candidate["value"] == "England"
    assert character_idea_candidate is not None
    assert "people she knows" in character_idea_candidate["value"]
    assert "things she saw" in character_idea_candidate["value"]
    assert "her imagination" in character_idea_candidate["value"]
    assert realistic_first_pet_candidate is not None
    assert realistic_first_pet_candidate["value"] == "Susie"


def test_answer_contains_gold_accepts_polarity_short_choice_and_list_subset():
    assert _answer_contains_gold("Yes", "Yes, she is supportive")
    assert _answer_contains_gold("Likely no", "Likely no; though she likes reading, she wants to be a counselor")
    assert _answer_contains_gold("national park", "National park; she likes the outdoors")
    assert _answer_contains_gold("pottery, camping, painting, swimming", "pottery, camping, painting, swimming")


def test_answer_matches_blocks_numeric_false_positives_but_keeps_reasonable_short_matches():
    assert not _answer_matches("How many siblings do I have?", "27", "2")
    assert not _answer_matches("What discount did I get on the couch?", "Discount 8 10 off coupon", "10%")
    assert _answer_matches("Who did I listen to on the ride home?", "Ed Sheeran", "Ed Sheeran's Perfect")
    assert _answer_matches("When did John first organize a charity tournament with his friends?", "7 May 2022", "May 7, 2022")
    assert _answer_matches("When did Jolene's mother pass away?", "2022", "in 2022")
    assert _answer_matches("When is Caroline going to the transgender conference?", "10 July 2023", "July 2023")
    assert _answer_matches(
        "Where does Joanna get her ideas for the characters from?",
        "people she knows, things she saw, her imagination, personal experiences",
        "people she knows, things she saw, her imagination",
    )
    assert _answer_matches(
        "What idea did Jolene have to help underprivileged kids learn about STEM subjects on 9 February, 2023?",
        "engineers teach STEM to underprivileged kids",
        "A volunteer program where engineers teach STEM to underprivileged kids",
    )
    assert _answer_matches(
        "How does Jolene plan to involve local engineers in her idea of teaching STEM to underprivileged kids?",
        "guest speakers for workshops",
        "As guest speakers for workshops",
    )
    assert not _answer_matches("When did Melanie go camping in June?", "June 2023", "The week before 27 June 2023")
    assert _answer_matches("How many times has Nate taken his turtles on a walk?", "two", "Twice.")
    assert _answer_matches("Would she be more interested in a national park or an art museum?", "national park", "National park; she likes the outdoors")
    assert _answer_matches(
        "What activities does Melanie partake in?",
        "camping, painting, pottery",
        "pottery, camping, painting, swimming",
    )
    assert _answer_matches(
        "How did Melanie feel about her family after the accident?",
        "important and mean the world",
        "They are important and mean the world to her",
    )


def test_binary_judgment_adapter_handles_simple_yes_no_questions():
    no_candidate = _build_reasoning_adapter_candidate(
        query_id="q-surf-no",
        prompt="Has Jolene tried surfing?",
        candidate_rows=[
            {
                "memory_id": "m1",
                "score": 1.0,
                "text": "Jolene: I haven't tried surfing yet, but I did start paddleboarding this year.",
            }
        ],
        pseudo_memories=[{"candidate_target_speaker": "jolene"}],
    )
    yes_candidate = _build_reasoning_adapter_candidate(
        query_id="q-surf-yes",
        prompt="Has Jolene tried surfing?",
        candidate_rows=[
            {
                "memory_id": "m1",
                "score": 1.0,
                "text": "Jolene: I tried surfing on our beach trip last summer and loved it.",
            }
        ],
        pseudo_memories=[{"candidate_target_speaker": "jolene"}],
    )

    assert no_candidate is not None
    assert yes_candidate is not None
    assert no_candidate["value"] == "No"
    assert yes_candidate["value"] == "Yes"


def test_candidate_extraction_filters_boilerplate_and_person_false_starts():
    field_answer = _extract_candidate_answer(
        "What fields would Caroline be likely to pursue in her educaton?",
        "caroline: I'm keen on counseling or working in mental health.\nmelanie: That's awesome, Caroline!",
    )
    support_answer = _extract_candidate_answer(
        "Who supports Caroline when she has a negative experience?",
        "caroline: Transitioning wasn't easy and acceptance wasn't either, but the help I got from friends, family and people I looked up to was invaluable.",
    )

    assert "awesome" not in field_answer["value"].lower()
    assert "mental health" in field_answer["value"].lower()
    assert not _looks_like_person_or_group_candidate("It's")
    assert not _looks_like_person_or_group_candidate("Transitioning")
    assert _looks_like_person_or_group_candidate("Ed Sheeran")
    assert "friends" in support_answer["value"].lower()
    assert "family" in support_answer["value"].lower()


def test_generic_and_event_reasoning_adapters_extract_supported_answers():
    research_adapter = _build_generic_reasoning_adapter_candidate(
        query_id="q-research",
        prompt="What did Caroline research?",
        candidate_rows=[
            {"memory_id": "m1", "score": 1.0, "text": "Caroline: Here's one of the adoption agencies I'm looking into."},
            {"memory_id": "m2", "score": 0.7, "text": "Caroline: I went to a council meeting for adoption."},
        ],
        pseudo_memories=[{"candidate_target_speaker": "caroline"}],
    )
    reflection_adapter = _build_generic_reasoning_adapter_candidate(
        query_id="q-reflect",
        prompt="What did Melanie realize after the charity race?",
        candidate_rows=[
            {
                "memory_id": "m1",
                "score": 1.0,
                "text": "Melanie: The event was really thought-provoking. I'm starting to realize that self-care is really important.",
            }
        ],
        pseudo_memories=[{"candidate_target_speaker": "melanie"}],
    )
    event_adapter = _build_event_reasoning_adapter_candidate(
        query_id="q-events",
        prompt="What LGBTQ+ events has Caroline participated in?",
        candidate_rows=[
            {"memory_id": "m1", "score": 1.0, "text": "Caroline: Last week I went to an LGBTQ+ pride parade."},
            {"memory_id": "m2", "score": 0.9, "text": "Caroline: I went to a LGBTQ support group yesterday and it was powerful."},
            {"memory_id": "m3", "score": 0.8, "text": "Caroline: I wanted to tell you about my school event last week. I talked about my transgender journey to students."},
        ],
        pseudo_memories=[{"candidate_target_speaker": "caroline"}],
    )
    music_event_adapter = _build_event_reasoning_adapter_candidate(
        query_id="q-music-events",
        prompt="What music events has John attended?",
        candidate_rows=[
            {
                "memory_id": "m1",
                "score": 1.0,
                "text": "John: Last week, we had a blast at a live music event. Seeing everyone dancing was awesome.",
            },
            {
                "memory_id": "m2",
                "score": 0.92,
                "text": "John: Just last week, I found a violin concert that we all enjoyed. It's all about making memories together.",
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "john"}],
    )
    business_event_adapter = _build_event_reasoning_adapter_candidate(
        query_id="q-business-events",
        prompt="Which events has Jon participated in to promote his business venture?",
        candidate_rows=[
            {
                "memory_id": "m1",
                "score": 1.0,
                "text": "Jon: Yesterday I chose to go to networking events to make things happen.",
            },
            {
                "memory_id": "m2",
                "score": 0.72,
                "text": "Jon: Yesterday, I went to a fair to show off my studio, it was both stressful and great!",
            },
            {
                "memory_id": "m3",
                "score": 0.68,
                "text": "Jon: I joined a dance competition to get my name out there and meet new people.",
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "jon"}],
    )

    assert research_adapter is not None
    assert reflection_adapter is not None
    assert event_adapter is not None
    assert music_event_adapter is not None
    assert business_event_adapter is not None
    assert research_adapter["value"] == "adoption agencies"
    assert reflection_adapter["value"] == "self-care is important"
    assert "pride parade" in event_adapter["value"]
    assert "support group" in event_adapter["value"]
    assert "live music event" in music_event_adapter["value"]
    assert "violin concert" in music_event_adapter["value"]
    assert "networking events" in business_event_adapter["value"]
    assert "fair" in business_event_adapter["value"]


def test_event_prompt_extractors_handle_workshop_and_fundraiser_phrases():
    workshop_answer = _extract_candidate_answer(
        "What workshop did Dave get picked for on 11 August, 2023?",
        "Dave: Guess what? I got picked for a car mod workshop. Gonna get better at it and learn something new!",
        target_speaker="dave",
    )
    fundraiser_answer = _extract_candidate_answer(
        "What event is Maria getting ready for at the shelter on May 25, 2023?",
        "Maria: I'm busy at the shelter getting ready for a fundraiser next week. Hopefully I can raise enough to cover basic needs.",
        target_speaker="maria",
    )

    assert workshop_answer["canonical_value"] == "car mod workshop"
    assert fundraiser_answer["canonical_value"] == "fundraiser"


def test_name_reasoning_adapter_and_prompt_typing_handle_lists_cleanly():
    single_pet_adapter = _build_reasoning_adapter_candidate(
        query_id="q-cat",
        prompt="What is the name of my cat?",
        candidate_rows=[
            {
                "memory_id": "m0",
                "score": 1.0,
                "text": "user: By the way, my cat's name is Luna, and she's been such a sweetie.\nassistant: Do you want ideas for new toys?",
            }
        ],
        pseudo_memories=[{"candidate_target_speaker": "user"}],
    )
    pet_adapter = _build_reasoning_adapter_candidate(
        query_id="q-pets",
        prompt="What are Melanie's pets' names?",
        candidate_rows=[
            {
                "memory_id": "m1",
                "score": 1.0,
                "text": "Melanie: My pets' names are Oliver, Luna, and Bailey.",
            }
        ],
        pseudo_memories=[{"candidate_target_speaker": "melanie"}],
    )
    artist_adapter = _build_reasoning_adapter_candidate(
        query_id="q-artists",
        prompt="What musical artists/bands has Melanie seen?",
        candidate_rows=[
            {
                "memory_id": "m1",
                "score": 1.0,
                "text": "Melanie: I saw Matt Patterson at my daughter's birthday and caught Summer Sounds last month.",
            }
        ],
        pseudo_memories=[{"candidate_target_speaker": "melanie"}],
    )

    assert single_pet_adapter is not None
    assert pet_adapter is not None
    assert artist_adapter is not None
    assert single_pet_adapter["value"] == "Luna"
    assert "Oliver" in pet_adapter["value"]
    assert "Luna" in pet_adapter["value"]
    assert "Matt Patterson" in artist_adapter["value"]
    assert "Summer Sounds" in artist_adapter["value"]
    assert _infer_answer_type("What are Melanie's pets' names?") == "pet_name"
    assert _infer_answer_type("What musical artists/bands has Melanie seen?") == "person_name"
    assert _infer_answer_type("What workshop did Caroline attend recently?") == "event_name"
    assert _infer_answer_type("What symbols are important to Caroline?") == "item_name"
    assert _infer_answer_type("What game was the second tournament that Nate won based on?") == "title_or_name"
    assert _infer_answer_type("What games has John played with his friends at charity tournaments?") == "title_or_name"
    assert _infer_answer_type("What is the favorite game Jolene plays with her partner?") == "title_or_name"
    assert _infer_answer_type("What game genre did John start exploring instead of shooters?") == "item_name"
    assert _infer_answer_type("What instrument is Tim learning to play in December 2023?") == "item_name"


def test_shared_item_adapter_handles_both_prompts_and_cross_speaker_overlap():
    movie_adapter = _build_reasoning_adapter_candidate(
        query_id="q-both-movies",
        prompt="What movies have both Joanna and Nate seen?",
        candidate_rows=[
            {
                "memory_id": "m1",
                "score": 1.0,
                "text": (
                    "Joanna: I rewatched Little Women and Lord of the Rings this week.\n"
                    "Nate: Same here, I saw Little Women again and Lord of the Rings with friends."
                ),
            }
        ],
        pseudo_memories=[{"candidate_target_speaker": "joanna"}],
    )
    beauty_adapter = _build_reasoning_adapter_candidate(
        query_id="q-both-beauty",
        prompt="What do both Joanna and Nate appreciate the beauty of?",
        candidate_rows=[
            {
                "memory_id": "m2",
                "score": 1.0,
                "text": (
                    "Joanna: The beauty of nature always helps me reset after a long week.\n"
                    "Nate: I appreciate the beauty of nature whenever I go hiking."
                ),
            }
        ],
        pseudo_memories=[{"candidate_target_speaker": "joanna"}],
    )

    assert movie_adapter is not None
    assert beauty_adapter is not None
    assert "Little Women" in movie_adapter["value"]
    assert "Lord of the Rings" in movie_adapter["value"]
    assert beauty_adapter["value"].lower() == "nature"


def test_targeted_phrase_patterns_cover_ice_cream_classes_jewelry_and_park_cases():
    ice_cream_answer = _extract_candidate_answer(
        "What type of ice cream does Joanna mention that Nate makes and is delicious?",
        "Joanna: Nate makes coconut milk ice cream and it's delicious.",
        target_speaker="joanna",
    )
    classes_answer = _extract_candidate_answer(
        "What type of classes did Audrey start with her pups recently on 4 August, 2023?",
        "Audrey: I just started agility classes with my pups and they love it.",
        target_speaker="audrey",
    )
    jewelry_answer = _extract_candidate_answer(
        "What type of jewelry does Audrey make?",
        "Audrey: I make jewelry from recycled objects I collect at flea markets.",
        target_speaker="audrey",
    )
    park_answer = _extract_candidate_answer(
        "What did Calvin and his friends arrange for in the park?",
        "Calvin: My friends and I arranged for regular walks together in the park every Sunday.",
        target_speaker="calvin",
    )

    assert ice_cream_answer["canonical_value"].lower() == "coconut milk ice cream"
    assert classes_answer["canonical_value"].lower() == "agility classes"
    assert "recycled objects" in jewelry_answer["canonical_value"].lower()
    assert park_answer["canonical_value"].lower() == "regular walks together"


def test_prompt_type_inference_handles_year_genre_and_setting_prompts():
    assert _infer_answer_type("Which year did Audrey adopt the first three of her dogs?") == "when"
    assert _infer_answer_type("What genre is Joanna's first screenplay?") == "item_name"
    assert _infer_answer_type("What was the setting for John and his wife's first dance?") == "where"
    assert _infer_answer_type("What kind of dance piece did Gina's team perform to win first place?") == "item_name"


def test_category_and_setting_prompts_extract_expected_values():
    genre_answer = _extract_candidate_answer(
        "What genre is Joanna's first screenplay?",
        "Joanna: It's a mix of drama and romance!",
        target_speaker="joanna",
    )
    setting_answer = _extract_candidate_answer(
        "What was the setting for John and his wife's first dance?",
        "John: We had our first dance at a cozy restaurant. It was dreamy with candlelight.",
        target_speaker="john",
    )
    year_answer = _extract_candidate_answer(
        "Which year did Audrey adopt the first three of her dogs?",
        "Audrey: I adopted the first three of my dogs in 2020, before adopting more later on.",
        target_speaker="audrey",
    )

    assert genre_answer["canonical_value"].lower() == "drama and romance"
    assert setting_answer["canonical_value"].lower() == "cozy restaurant"
    assert year_answer["canonical_value"] == "2020"
    assert float(year_answer["answer_type_match"]) >= 0.9


def test_category_prompt_ignores_single_token_exclamations_before_real_answer():
    answer = _extract_candidate_answer(
        "What genre is Joanna's first screenplay?",
        (
            "Joanna: Woo!\n"
            "Joanna: It's a mix of drama and romance!\n"
            "Joanna: I'm relieved it's finally done."
        ),
        target_speaker="joanna",
    )

    assert answer["canonical_value"].lower() == "drama and romance"


def test_when_extractor_pulls_relative_weekday_instead_of_snippet():
    answer = _extract_candidate_answer(
        "When did Caroline join a new activist group?",
        "Caroline: Hey Mel! A lot's happened since we last chatted - I just joined a new LGBTQ activist group last Tues.",
        target_speaker="caroline",
    )

    assert answer["canonical_value"].lower() == "last tues"


def test_shared_item_adapter_uses_media_context_and_cross_turn_reference():
    movie_adapter = _build_reasoning_adapter_candidate(
        query_id="q-both-movies-context",
        prompt="What movies have both Joanna and Nate seen?",
        candidate_rows=[
            {
                "memory_id": "m1",
                "score": 1.0,
                "text": (
                    'Joanna: I took your recommendation and watched "The Lord of the Rings" trilogy last night.\n'
                    "Nate: Glad you enjoyed it. It's probably the greatest trilogy of all time."
                ),
            },
            {
                "memory_id": "m2",
                "score": 0.8,
                "text": (
                    'Joanna: I am working on a script called "Finding Home" with my group.\n'
                    'Nate: "Finding Home" sounds really special.'
                ),
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "joanna"}],
    )

    assert movie_adapter is not None
    assert "The Lord of the Rings" in movie_adapter["value"]
    assert "Finding Home" not in movie_adapter["value"]


def test_category_item_prompts_prefer_descriptive_phrases_over_named_titles():
    genre_answer = _extract_candidate_answer(
        "What game genre did John start exploring instead of shooters?",
        (
            "John: Lately, I've been playing some different genres like strategy and RPG games instead of "
            'my usual shooters. I also started "The Witcher 3" and love it.'
        ),
        target_speaker="john",
    )
    music_answer = _extract_candidate_answer(
        "What type of music does Deborah find helpful during her yoga practice?",
        (
            'Deborah: I find instrumental tracks with mellow melodies and rhythms help create a peaceful vibe. '
            'One of my favorites is a track called "Savana."'
        ),
        target_speaker="deborah",
    )

    assert genre_answer["canonical_value"].lower() == "strategy and rpg games"
    assert music_answer["canonical_value"].lower() == "instrumental tracks with mellow melodies and rhythms"


def test_extract_candidate_answer_prefers_prompt_subject_for_suggestion_prompt():
    answer = _extract_candidate_answer(
        "What kind of water does Evan suggest Sam try as an alternative to soda?",
        (
            "Sam: I am trying to cut back on soda.\n"
            "Evan: Try flavored seltzer water instead. It can be a great alternative to soda.\n"
            "Sam: I've tried it before and it was nice."
        ),
    )

    assert answer["speaker"] == "evan"
    assert answer["canonical_value"].lower() == "flavored seltzer water"


def test_mixed_speaker_category_prompt_does_not_prefer_prompt_echo():
    answer = _extract_candidate_answer(
        "What type of music does Deborah find helpful during her yoga practice?",
        (
            "Jolene: I find music helps me. Any favorite tracks?\n"
            'Deborah: I find instrumental tracks with mellow melodies and rhythms help create a peaceful vibe. '
            'One of my favorites is a track called "Savana."'
        ),
        target_speaker="deborah",
    )

    assert answer["speaker"] == "deborah"
    assert answer["canonical_value"].lower() == "instrumental tracks with mellow melodies and rhythms"


def test_music_category_prompt_ignores_specific_track_titles_and_follow_up_questions():
    answer = _extract_candidate_answer(
        "What type of music does Deborah find helpful during her yoga practice?",
        (
            "Deborah: I find instrumental tracks with mellow melodies and rhythms help create a peaceful vibe. "
            'One of my favorites is a track called "Savana." What songs/artists do you like listening to during your practice?'
        ),
        target_speaker="deborah",
    )

    assert answer["canonical_value"].lower() == "instrumental tracks with mellow melodies and rhythms"


def test_title_extraction_ignores_low_signal_prefix_when_real_title_present():
    answer = _extract_candidate_answer(
        "What movie did Sam watch that motivated him to keep up with his routine?",
        "Sam: Anytime, Evan. I watched The Godfather and it weirdly motivated me to stay disciplined.",
        target_speaker="sam",
    )

    assert answer["canonical_value"] == "The Godfather"


def test_title_extraction_ignores_speaker_name_candidates():
    answer = _extract_candidate_answer(
        "What movie did Sam watch that motivated him to keep up with his routine?",
        (
            "Sam: Sam.\n"
            "Evan: Nice one.\n"
            "Sam: I watched The Godfather last night, and it motivated me to stay on track."
        ),
        target_speaker="sam",
    )

    assert answer["canonical_value"] == "The Godfather"


def test_person_name_and_media_title_extraction_cover_realistic_external_failures():
    child_answer = _extract_candidate_answer(
        "What is the name of John's one-year-old child?",
        "John: Our one-year-old is so cute, his name is Kyle!",
        target_speaker="john",
    )
    movie_answer = _extract_candidate_answer(
        "What movie did Joanna watch on 1 May, 2022?",
        'Joanna: I took your recommendation and watched "The Lord of the Rings" Trilogy last night!',
        target_speaker="joanna",
    )
    recommendation_answer = _extract_candidate_answer(
        "What book recommendation did Tim give to John for the trip?",
        (
            "Tim: Yeah! I think you'd love this fantasy novel by Patrick Rothfuss. "
            "It's a book that'll take you to a different world."
        ),
        target_speaker="tim",
    )
    finished_book_answer = _extract_candidate_answer(
        "What book did Tim just finish reading on 8th December, 2023?",
        (
            'Tim: I have not read that yet but I have heard great things! '
            'Just finished "A Dance with Dragons" and it is a really good story.'
        ),
        target_speaker="tim",
    )

    assert _infer_answer_type("What is the name of John's one-year-old child?") == "person_name"
    assert child_answer["canonical_value"] == "Kyle"
    assert movie_answer["canonical_value"] == "The Lord of the Rings"
    assert recommendation_answer["canonical_value"].lower() == "this fantasy novel by patrick rothfuss"
    assert recommendation_answer["canonical_value"] != "Patrick Rothfuss"
    assert finished_book_answer["canonical_value"] == "A Dance with Dragons"


def test_name_and_title_selection_ignore_relation_noise_and_non_media_clauses():
    child_adapter = _build_reasoning_adapter_candidate(
        query_id="q-child-name",
        prompt="What is the name of John's one-year-old child?",
        candidate_rows=[
            {
                "memory_id": "m-child",
                "score": 1.0,
                "text": "John: Our one-year-old is so cute, his name is Kyle!",
            },
            {
                "memory_id": "m-family",
                "score": 0.95,
                "text": "John: My family is awesome and we spend every weekend together.",
            },
        ],
        pseudo_memories=[{"candidate_target_speaker": "john"}],
    )
    recommendation_answer = _extract_candidate_answer(
        "What book recommendation did Tim give to John for the trip?",
        (
            "Tim: I recently went to an event and it was fantastic.\n"
            "Tim: Yeah! I think you'd love this fantasy novel by Patrick Rothfuss.\n"
            "Tim: Harry Potter is my favorite book."
        ),
        target_speaker="tim",
    )
    finished_answer = _extract_candidate_answer(
        "What book did Tim just finish reading on 8th December, 2023?",
        (
            'Tim: I am currently reading "Dune" by Frank Herbert.\n'
            'Tim: Just finished "A Dance with Dragons" and it is a really good story.\n'
            'Tim: "The Name of the Wind" is great too.'
        ),
        target_speaker="tim",
    )

    assert child_adapter is not None
    assert child_adapter["value"] == "Kyle"
    assert recommendation_answer["canonical_value"].lower() == "this fantasy novel by patrick rothfuss"
    assert finished_answer["canonical_value"] == "A Dance with Dragons"


def test_explicit_media_title_prompts_ignore_series_noise_and_cross_turn_brand_mentions():
    recommendation_answer = _extract_candidate_answer(
        "What book recommendation did Tim give to John for the trip?",
        (
            "Tim: Yeah! I think you'd love this fantasy novel by Patrick Rothfuss.\n"
            "Tim: Yeah, can't wait to check out the series."
        ),
        target_speaker="tim",
    )
    finished_answer = _extract_candidate_answer(
        "What book did Tim just finish reading on 8th December, 2023?",
        (
            'John: I am currently reading "Dune" by Frank Herbert.\n'
            'Tim: Just finished "A Dance with Dragons" and it is a really good story.\n'
            'Tim: I also heard about a fantasy novel called The Name of the Wind.'
        ),
        target_speaker="tim",
    )
    disney_movie_answer = _extract_candidate_answer(
        "Which Disney movie did Dave mention as one of his favorites?",
        (
            "Dave: It reminds me of one of my favorite Disney movies.\n"
            "Calvin: Ratatouille is one of my favorites!"
        ),
        target_speaker="dave",
    )

    assert recommendation_answer["canonical_value"].lower() == "this fantasy novel by patrick rothfuss"
    assert finished_answer["canonical_value"] == "A Dance with Dragons"
    assert disney_movie_answer["canonical_value"] == "Ratatouille"


def test_flight_ticket_prompts_are_typed_as_where_and_extract_destination():
    answer = _extract_candidate_answer(
        "What did Calvin book a flight ticket for on 1st September 2023?",
        (
            "Dave: I came back from San Francisco yesterday with a lot of ideas.\n"
            "Calvin: I booked a flight ticket to Boston last week and cannot wait for the trip."
        ),
        target_speaker="calvin",
    )

    assert _infer_answer_type("What did Calvin book a flight ticket for on 1st September 2023?") == "where"
    assert answer["canonical_value"] == "Boston"


def test_country_prompts_are_typed_as_where():
    answer = _extract_candidate_answer(
        "What country is Caroline's grandma from?",
        "Caroline: My grandma is from Sweden, and I still want to visit her home country someday.",
        target_speaker="caroline",
    )

    assert _infer_answer_type("What country is Caroline's grandma from?") == "where"
    assert answer["canonical_value"] == "Sweden"


def test_country_prompts_can_normalize_common_city_mentions_to_countries():
    answer = _extract_candidate_answer(
        "Which country did James book tickets for in July 2022?",
        "James: I bought air tickets to Toronto, and I'm leaving the day after tomorrow evening.",
        target_speaker="james",
    )

    assert answer["canonical_value"] == "Canada"


def test_where_prompts_do_not_treat_salutations_as_locations():
    answer = _extract_candidate_answer(
        "Which country was Evan visiting in May 2023?",
        "Evan: I was visiting Canada in May 2023.\nJohn: Cheers Evan!",
        target_speaker="evan",
    )

    assert answer["canonical_value"] == "Canada"


def test_where_idea_prompts_extract_source_lists_not_salutation_fragments():
    answer = _extract_candidate_answer(
        "Where does James get his ideas from?",
        (
            "John: In general, where do you get ideas?\n"
            "James: I get them from various sources like books, movies, and even dreams.\n"
            "John: Hang on, let me grab them."
        ),
        target_speaker="james",
    )

    assert _infer_answer_type("Where does James get his ideas from?") == "generic"
    assert answer["canonical_value"] == "books, movies, dreams"


def test_where_prompts_capture_through_locations_and_strip_weekday_tails():
    travel_answer = _extract_candidate_answer(
        "Where did Sam and his mate plan to try kayaking?",
        (
            "Sam: Thanks for the idea, my mate and I are just around the corner from kayaking on the lake.\n"
            "Sam: We're traveling through Lake Tahoe! I heard it's great for kayaking."
        ),
        target_speaker="sam",
    )
    country_answer = _extract_candidate_answer(
        "Which country was Tim visiting in the second week of November?",
        "Tim: I went to a castle during my trip to the UK last Friday and it was unbelievable!",
        target_speaker="tim",
    )

    assert travel_answer["canonical_value"] == "Lake Tahoe"
    assert country_answer["canonical_value"] == "UK"


def test_salutation_clause_detects_time_of_day_and_long_time_no_see_greetings():
    assert _is_salutation_clause("Morning, Evan.")
    assert _is_salutation_clause("Hey Nate, long time no see!")


def test_prompt_session_date_alignment_detects_exact_match():
    assert (
        _prompt_session_date_alignment(
            "What game is John hooked on playing on 5 November, 2022?",
            {"session_date": "5:20 pm on 5 November, 2022"},
        )
        == 1.0
    )
    assert (
        _prompt_session_date_alignment(
            "What game is John hooked on playing on 5 November, 2022?",
            {"session_date": "9:16 am on 10 August, 2022"},
        )
        == 0.0
    )


def test_comparative_prompt_detection_avoids_plain_temporal_or_disjunction_phrases():
    assert _is_comparative_prompt("Which event happened first, my cousin's wedding or Michael's engagement party?")
    assert _is_comparative_prompt("Who became a parent first, Rachel or Alex?")
    assert _is_comparative_prompt("How many months lapsed between Sam's first and second doctor's appointment?")
    assert not _is_comparative_prompt("How did Melanie feel after the accident?")
    assert not _is_comparative_prompt("What areas of the U.S. has John been to or is planning to go to?")
    assert not _is_comparative_prompt("What genre is Joanna's first screenplay?")
    assert not _is_comparative_prompt("What was the setting for John and his wife's first dance?")


def test_subject_paint_prompts_extract_visual_subjects_and_field_false_positive_is_blocked():
    painted_subject = _extract_candidate_answer(
        "What subject have Caroline and Melanie both painted?",
        (
            "Melanie: We both helped with the painting - it was great bonding over it and chatting about nature. "
            "[image_caption] a photo of a painting of a sunset with a palm tree"
        ),
        target_speaker="melanie",
    )

    assert _infer_answer_type("What inspired Joanna to take a picture of the sunset in the field near Fort Wayne?") == "generic"
    assert _infer_answer_type("What subject have Caroline and Melanie both painted?") == "item_name"
    assert painted_subject["canonical_value"].lower() == "sunset"
    assert _answer_matches("What subject have Caroline and Melanie both painted?", "sunset", "Sunsets")


def test_career_goal_and_milestone_prompts_use_local_adapter():
    goal_answer = _extract_candidate_answer(
        "What are John's goals with regards to his basketball career?",
        (
            "John: My goal is to improve my shooting percentage this season.\n"
            "John: Yeah! Winning a championship is my number one goal."
        ),
        target_speaker="john",
    )
    off_court_answer = _extract_candidate_answer(
        "What are John's goals for his career that are not related to his basketball skills?",
        (
            "John: I'm exploring endorsement opportunities and learning how to build my brand.\n"
            "John: I want to use my platform to make a positive difference, maybe even start a foundation and do charity work."
        ),
        target_speaker="john",
    )
    milestone_answer = _extract_candidate_answer(
        "What career milestone did John achieve recently in September 2022?",
        "John: I just achieved a major career milestone - making my first mobile game! It's launching next month.",
        target_speaker="john",
    )

    assert _infer_answer_type("What are John's goals with regards to his basketball career?") == "generic"
    assert _infer_answer_type("What are John's goals for his career that are not related to his basketball skills?") == "generic"
    assert _infer_answer_type("What career milestone did John achieve recently in September 2022?") == "generic"
    assert goal_answer["canonical_value"] == "improve shooting percentage, win a championship"
    assert off_court_answer["canonical_value"] == "get endorsements, build his brand, do charity work"
    assert milestone_answer["canonical_value"] == "making his first mobile game"


def test_career_path_and_alternative_career_prompts_extract_grounded_roles():
    path_answer = _extract_candidate_answer(
        "What career path has Caroline decided to persue?",
        (
            "Caroline: I'm thinking of working with trans people, helping them accept themselves and supporting their mental health.\n"
            "Caroline: Counseling and mental health is the way to go for me."
        ),
        target_speaker="caroline",
    )
    alternative_answer = _extract_candidate_answer(
        "What alternative career might Nate consider after gaming?",
        "Nate: Turtles really bring me joy and peace. I love taking care of them.",
        target_speaker="nate",
    )

    assert path_answer["canonical_value"] == "counseling or mental health for transgender people"
    assert _infer_answer_type("What alternative career might Nate consider after gaming?") == "occupation"
    assert alternative_answer["canonical_value"] == "animal keeper working with turtles"


def test_career_high_prompt_collects_point_and_assist_highs():
    answer = _extract_candidate_answer(
        "Which career-high performances did John achieve in 2023?",
        (
            "John: Last week I scored 40 points, my highest ever.\n"
            "John: By the way, I had a career-high in assists last Friday in our big game."
        ),
        target_speaker="john",
    )

    assert answer["canonical_value"] == "highest point score, highest assist"


def test_group_and_activity_prompts_route_to_more_specific_extractors():
    group_answer = _extract_candidate_answer(
        "What kind of online group did John join?",
        "John: I joined a service-focused online group last week and it has been really meaningful.",
        target_speaker="john",
    )
    hiking_answer = _extract_candidate_answer(
        "In what activity did Maria and her church friends participate in July 2023?",
        "Maria: I had a great experience last weekend hiking with my church friends - it felt refreshing.",
        target_speaker="maria",
    )
    community_answer = _extract_candidate_answer(
        "What activity did Maria take up with her friends from church in August 2023?",
        "Maria: Yesterday I took up some community work with my friends from church, and it felt important.",
        target_speaker="maria",
    )

    assert _infer_answer_type("What kind of online group did John join?") == "group_name"
    assert _infer_answer_type("In what activity did Maria and her church friends participate in July 2023?") == "activity_list"
    assert group_answer["canonical_value"] == "service-focused online group"
    assert hiking_answer["canonical_value"] == "hiking"
    assert community_answer["canonical_value"] == "community work"


def test_generic_prompt_patterns_extract_gifts_awareness_plans_and_pets():
    gift_answer = _extract_candidate_answer(
        "What was grandma's gift to Caroline?",
        "Caroline: This necklace is super special to me - a gift from my grandma in Sweden.",
        target_speaker="caroline",
    )
    awareness_answer = _extract_candidate_answer(
        "What did the charity race raise awareness for?",
        "Melanie: The charity race raised awareness for mental health and meant a lot to me.",
        target_speaker="melanie",
    )
    summer_answer = _extract_candidate_answer(
        "What are Caroline's plans for the summer?",
        "Caroline: Researching adoption agencies - it's been a dream to give kids a loving home.",
        target_speaker="caroline",
    )
    pet_answer = _extract_candidate_answer(
        "What pet does Caroline have?",
        "Caroline: My guinea pig always cheers me up after a hard day.",
        target_speaker="caroline",
    )

    assert _infer_answer_type("What pet does Caroline have?") == "item_name"
    assert gift_answer["canonical_value"] == "necklace"
    assert awareness_answer["canonical_value"] == "mental health"
    assert summer_answer["canonical_value"] == "researching adoption agencies"
    assert pet_answer["canonical_value"] == "guinea pig"


def test_external_direct_valid_adapter_avoids_flat_scores_with_tiny_raw_probabilities(monkeypatch):
    run_root = Path.cwd() / ".tmp_tests"
    run_root.mkdir(parents=True, exist_ok=True)
    run_dir = run_root / "external_pipeline_tiny_scores"
    retrieval_dir = run_dir / "longmemeval" / "dense_e5_rerank"
    write_jsonl(
        retrieval_dir / "retrieval_diagnostics.jsonl",
        [
            {
                "query_id": "lm-flat-1",
                "benchmark": "longmemeval",
                "prompt": "Where did I redeem a $5 coupon on coffee creamer?",
                "gold_answer": "Target",
                "answer_support_ids": ["lm-flat-1_m0000"],
                "retrieve_top_k": 2,
                "final_top_k": 2,
                "support_recall_at_retrieve_k": 1.0,
                "support_recall_at_final_k": 1.0,
                "support_hit_at_1": 1.0,
                "support_mrr": 1.0,
                "retrieved": [
                    {
                        "memory_id": "lm-flat-1_m0000",
                        "score": 0.91,
                        "text": "user: I actually redeemed a $5 coupon on coffee creamer at Target last Friday.\nassistant: Nice.",
                    },
                    {
                        "memory_id": "lm-flat-1_m0001",
                        "score": 0.74,
                        "text": "user: I am thinking about a board game subscription like Board Game Bento.\nassistant: That could be fun.",
                    },
                ],
                "final_ranked": [
                    {
                        "memory_id": "lm-flat-1_m0000",
                        "score": 0.91,
                        "text": "user: I actually redeemed a $5 coupon on coffee creamer at Target last Friday.\nassistant: Nice.",
                    },
                    {
                        "memory_id": "lm-flat-1_m0001",
                        "score": 0.74,
                        "text": "user: I am thinking about a board game subscription like Board Game Bento.\nassistant: That could be fun.",
                    },
                ],
            }
        ],
    )

    def _tiny_loader(_model_dir):
        return type(
            "_TinyBundles",
            (),
            {
                "relevance_bundle": _TinyRelevanceBundle(),
                "query_validity_bundles": {
                    "useful_label": _TinyQueryValidityBundle("useful_label"),
                    "valid_label": _TinyQueryValidityBundle("valid_label"),
                },
                "anti_support_bundle": _TinyAntiSupportBundle(),
                "value_resolver_bundle": _FakeValueResolverBundle(),
            },
        )()

    import memory_collapse.external_pipeline as external_pipeline

    monkeypatch.setattr(external_pipeline, "_load_external_method_bundles", _tiny_loader)

    outputs = run_external_end_to_end(
        benchmark_name="longmemeval",
        retrieval_inputs={"dense_e5_rerank": retrieval_dir},
        methods=[DIRECT_VALID_METHOD, DIRECT_VALID_RESOLVER_METHOD],
        output_root=run_dir / "outputs",
        summary_root=run_dir / "outputs",
        model_dir=run_dir / "fake_models",
        final_k=2,
    )

    direct_rows = read_jsonl(Path(outputs["diagnostics"][f"dense_e5_rerank:{DIRECT_VALID_METHOD}"]))
    resolver_rows = read_jsonl(Path(outputs["diagnostics"][f"dense_e5_rerank:{DIRECT_VALID_RESOLVER_METHOD}"]))

    assert direct_rows[0]["predicted_answer"] == "Target"
    assert resolver_rows[0]["predicted_answer"] == "Target"
    assert direct_rows[0]["candidate_value_scores"][0]["score"] > direct_rows[0]["candidate_value_scores"][1]["score"]
    assert resolver_rows[0]["candidate_value_scores"][0]["score"] > resolver_rows[0]["candidate_value_scores"][1]["score"]
    assert direct_rows[0]["direct_valid_metadata"]["adapter_version"] == "external_v1"
    assert float(
        direct_rows[0]["direct_valid_metadata"]["component_debug"]["lm-flat-1_m0000"]["raw_pi_hat_direct"]
    ) < 0.001


@pytest.mark.parametrize(
    ("module_name", "runner_fn"),
    [
        ("memory_collapse.external_pipeline", run_external_end_to_end),
        ("memory_collapse.external_pipeline_v0", run_external_end_to_end_v0),
    ],
)
def test_external_end_to_end_runner_writes_diagnostics_metrics_and_summary(monkeypatch, module_name, runner_fn):
    run_root = Path.cwd() / ".tmp_tests"
    run_root.mkdir(parents=True, exist_ok=True)
    run_dir = run_root / module_name.rsplit(".", 1)[-1]
    retrieval_dir = run_dir / "longmemeval" / "dense_e5_rerank"
    write_jsonl(
        retrieval_dir / "retrieval_diagnostics.jsonl",
        [
            {
                "query_id": "lm-1",
                "benchmark": "longmemeval",
                "prompt": "Where did Alice move?",
                "gold_answer": "Berlin",
                "answer_support_ids": ["lm-1_m0000"],
                "retrieve_top_k": 2,
                "final_top_k": 2,
                "support_recall_at_retrieve_k": 1.0,
                "support_recall_at_final_k": 1.0,
                "support_hit_at_1": 1.0,
                "support_mrr": 1.0,
                "retrieved": [
                    {
                        "memory_id": "lm-1_m0000",
                        "score": 0.98,
                        "text": "Alice moved to Berlin last spring.",
                    },
                    {
                        "memory_id": "lm-1_m0001",
                        "score": 0.20,
                        "text": "Alice bought apples from the market.",
                    },
                ],
                "final_ranked": [
                    {
                        "memory_id": "lm-1_m0000",
                        "score": 0.98,
                        "text": "Alice moved to Berlin last spring.",
                    },
                    {
                        "memory_id": "lm-1_m0001",
                        "score": 0.20,
                        "text": "Alice bought apples from the market.",
                    },
                ],
            },
            {
                "query_id": "lm-2",
                "benchmark": "longmemeval",
                "prompt": "What refund did the customer ask for?",
                "gold_answer": "travel refund",
                "answer_support_ids": ["lm-2_m0000"],
                "retrieve_top_k": 2,
                "final_top_k": 2,
                "support_recall_at_retrieve_k": 1.0,
                "support_recall_at_final_k": 1.0,
                "support_hit_at_1": 1.0,
                "support_mrr": 1.0,
                "retrieved": [
                    {
                        "memory_id": "lm-2_m0000",
                        "score": 0.91,
                        "text": "The customer asked for a travel refund after the canceled booking.",
                    },
                    {
                        "memory_id": "lm-2_m0001",
                        "score": 0.30,
                        "text": "The agent confirmed identity before continuing.",
                    },
                ],
                "final_ranked": [
                    {
                        "memory_id": "lm-2_m0000",
                        "score": 0.91,
                        "text": "The customer asked for a travel refund after the canceled booking.",
                    },
                    {
                        "memory_id": "lm-2_m0001",
                        "score": 0.30,
                        "text": "The agent confirmed identity before continuing.",
                    },
                ],
            },
        ],
    )

    def _fake_loader(_model_dir):
        return type(
            "_Bundles",
            (),
            {
                "relevance_bundle": _FakeRelevanceBundle(),
                "query_validity_bundles": {
                    "useful_label": _FakeQueryValidityBundle("useful_label"),
                    "valid_label": _FakeQueryValidityBundle("valid_label"),
                },
                "anti_support_bundle": _FakeAntiSupportBundle(),
                "value_resolver_bundle": _FakeValueResolverBundle(),
            },
        )()

    runner_module = importlib.import_module(module_name)
    monkeypatch.setattr(runner_module, "_load_external_method_bundles", _fake_loader)

    outputs = runner_fn(
        benchmark_name="longmemeval",
        retrieval_inputs={"dense_e5_rerank": retrieval_dir},
        methods=[RETRIEVAL_ONLY_BASELINE, DIRECT_VALID_RESOLVER_METHOD],
        output_root=run_dir / "outputs",
        summary_root=run_dir / "outputs",
        model_dir=run_dir / "fake_models",
        final_k=2,
    )

    summary_csv = Path(outputs["summary_csv"])
    summary_md = Path(outputs["summary_md"])
    metrics_csv = Path(outputs["metrics_csv"])
    retrieval_diag = Path(outputs["diagnostics"]["dense_e5_rerank:retrieval_only_baseline"])
    resolver_diag = Path(outputs["diagnostics"][f"dense_e5_rerank:{DIRECT_VALID_RESOLVER_METHOD}"])

    assert summary_csv.exists()
    assert summary_md.exists()
    assert metrics_csv.exists()
    assert retrieval_diag.exists()
    assert resolver_diag.exists()

    retrieval_rows = read_jsonl(retrieval_diag)
    resolver_rows = read_jsonl(resolver_diag)
    metrics = pd.read_csv(metrics_csv)
    summary = pd.read_csv(summary_csv)

    assert len(retrieval_rows) == 2
    assert len(resolver_rows) == 2
    assert retrieval_rows[0]["candidate_value_scores"]
    assert resolver_rows[0]["direct_valid_metadata"]["component_debug"]
    assert resolver_rows[0]["resolver_metadata"]["used"] is True
    assert set(metrics["method"]) == {RETRIEVAL_ONLY_BASELINE, DIRECT_VALID_RESOLVER_METHOD}
    assert set(summary["method"]) == {RETRIEVAL_ONLY_BASELINE, DIRECT_VALID_RESOLVER_METHOD}
    assert float(metrics["accuracy"].min()) >= 1.0
    assert "dense_e5_rerank" in summary_md.read_text(encoding="utf-8")
    assert DIRECT_VALID_RESOLVER_METHOD in summary_md.read_text(encoding="utf-8")
