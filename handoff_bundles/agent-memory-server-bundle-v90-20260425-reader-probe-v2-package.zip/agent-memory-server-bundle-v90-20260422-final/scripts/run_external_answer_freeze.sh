#!/usr/bin/env bash

set -euo pipefail

PROJECT_ROOT="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
PYTHON_BIN="${PYTHON_BIN:-python}"
RETRIEVAL_ROOT="${RETRIEVAL_ROOT:-$PROJECT_ROOT/outputs/external_runs}"
FREEZE_ROOT="${FREEZE_ROOT:-$PROJECT_ROOT/outputs/external_freeze_v90_aligned_r1}"
MODEL_DIR="${MODEL_DIR:-$PROJECT_ROOT/artifacts/external_answer_models}"
RUN_OPEN_MODEL_BASELINES="${RUN_OPEN_MODEL_BASELINES:-1}"

export PYTHONPATH="${PROJECT_ROOT}/src:${PYTHONPATH:-}"

run_answer_eval() {
  local benchmark="$1"
  local summary_dir="$2"

  "$PYTHON_BIN" -m memory_collapse.cli run_external_end_to_end \
    --benchmark "$benchmark" \
    --retrieval-variant tfidf \
    --retrieval-variant dense_e5 \
    --retrieval-variant dense_e5_rerank \
    --retrieval-variant hybrid_bge_m3 \
    --retrieval-variant hybrid_bge_m3_rerank \
    --input-root "${RETRIEVAL_ROOT}/${benchmark}" \
    --method retrieval_only_baseline \
    --method proposed_learned_direct_valid \
    --method proposed_learned_direct_valid_resolver \
    --model-dir "$MODEL_DIR" \
    --output-root "$FREEZE_ROOT" \
    --summary-root "$summary_dir"
}

mkdir -p "$FREEZE_ROOT"

run_answer_eval "longmemeval" "${FREEZE_ROOT}/summary_longmemeval"
run_answer_eval "locomo" "${FREEZE_ROOT}/summary_locomo"

if [[ "$RUN_OPEN_MODEL_BASELINES" == "1" ]]; then
  bash "$PROJECT_ROOT/scripts/run_external_open_model_baselines.sh"
fi

"$PYTHON_BIN" "$PROJECT_ROOT/scripts/analyze_external_failures.py" \
  --pred-root "$FREEZE_ROOT" \
  --retrieval-root "$RETRIEVAL_ROOT" \
  --output-dir "${FREEZE_ROOT}/failure_slices"

echo "done"
echo "freeze_root=$FREEZE_ROOT"
