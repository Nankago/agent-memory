#!/usr/bin/env python

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

from memory_collapse.external_pipeline import _infer_answer_type, _is_comparative_prompt


BENCHMARKS = ["longmemeval", "locomo"]
VARIANTS = [
    "tfidf",
    "dense_e5",
    "dense_e5_rerank",
    "hybrid_bge_m3",
    "hybrid_bge_m3_rerank",
]


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def write_csv(rows: list[dict[str, Any]], path: Path) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def normalize_answer(text: str | None) -> str:
    if text is None:
        return ""
    text = str(text).lower()
    text = "".join(char if char.isalnum() else " " for char in text)
    return " ".join(text.split())


def question_bucket(prompt: str) -> str:
    answer_type = _infer_answer_type(prompt)
    if _is_comparative_prompt(prompt):
        return f"{answer_type}:comparative"
    return answer_type


def confidence_margin(row: dict[str, Any]) -> float | None:
    scores = row.get("candidate_value_scores") or []
    if not scores:
        return None
    top = float(scores[0].get("score", 0.0))
    second = float(scores[1].get("score", 0.0)) if len(scores) > 1 else 0.0
    return top - second


def failure_bucket(row: dict[str, Any], prompt: str) -> str:
    if bool(row.get("is_correct")):
        return "correct"
    support = row.get("retrieval_support_recall_at_final_k")
    support_value = float(support) if support not in (None, "") else 0.0
    margin = confidence_margin(row)
    predicted = normalize_answer(row.get("predicted_answer"))
    if support_value <= 0.0:
        return "retrieval_miss"
    if not predicted:
        return "empty_prediction"
    if _is_comparative_prompt(prompt):
        return "comparative_reasoning"
    if margin is not None and margin >= 0.20:
        return "confident_selection_error"
    return "supported_but_wrong"


def build_joined_rows(pred_root: Path, retrieval_root: Path) -> list[dict[str, Any]]:
    joined_rows: list[dict[str, Any]] = []
    for benchmark in BENCHMARKS:
        for variant in VARIANTS:
            retrieval_rows = {
                row["query_id"]: row
                for row in read_jsonl(retrieval_root / benchmark / variant / "retrieval_diagnostics.jsonl")
            }
            if not retrieval_rows:
                continue
            for method in discover_methods(pred_root, benchmark, variant):
                diag_path = pred_root / benchmark / variant / method / "prediction_diagnostics.jsonl"
                diagnostics = read_jsonl(diag_path)
                for row in diagnostics:
                    retrieval_row = retrieval_rows.get(row["query_id"], {})
                    prompt = str(retrieval_row.get("prompt", ""))
                    joined_rows.append(
                        {
                            "benchmark": benchmark,
                            "variant": variant,
                            "method": method,
                            "query_id": row["query_id"],
                            "prompt": prompt,
                            "gold_answer": str(row.get("gold_answer", "")),
                            "predicted_answer": str(row.get("predicted_answer", "")),
                            "is_correct": bool(row.get("is_correct")),
                            "exact_match": bool(row.get("exact_match")),
                            "question_bucket": question_bucket(prompt),
                            "answer_type": _infer_answer_type(prompt),
                            "is_comparative": bool(_is_comparative_prompt(prompt)),
                            "failure_bucket": failure_bucket(row, prompt),
                            "retrieval_support_recall_at_final_k": row.get("retrieval_support_recall_at_final_k"),
                            "confidence": row.get("confidence"),
                            "confidence_margin": confidence_margin(row),
                        }
                    )
    return joined_rows


def discover_methods(pred_root: Path, benchmark: str, variant: str) -> list[str]:
    variant_dir = pred_root / benchmark / variant
    if not variant_dir.exists():
        return []
    methods: list[str] = []
    for child in sorted(variant_dir.iterdir()):
        if not child.is_dir():
            continue
        if (child / "prediction_diagnostics.jsonl").exists():
            methods.append(child.name)
    return methods


def summarize_by(rows: list[dict[str, Any]], group_key: str) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[(row["benchmark"], row["variant"], row["method"], row[group_key])].append(row)
    summary_rows: list[dict[str, Any]] = []
    for (benchmark, variant, method, slice_value), group in sorted(grouped.items()):
        num_queries = len(group)
        num_failures = sum(not bool(item["is_correct"]) for item in group)
        accuracy = sum(bool(item["is_correct"]) for item in group) / max(num_queries, 1)
        summary_rows.append(
            {
                "benchmark": benchmark,
                "variant": variant,
                "method": method,
                group_key: slice_value,
                "num_queries": num_queries,
                "num_failures": num_failures,
                "accuracy": round(accuracy, 6),
                "failure_rate": round(num_failures / max(num_queries, 1), 6),
            }
        )
    return summary_rows


def render_markdown(question_rows: list[dict[str, Any]], failure_rows: list[dict[str, Any]]) -> str:
    lines: list[str] = ["# External Failure Slices", ""]
    methods = sorted({row["method"] for row in question_rows} | {row["method"] for row in failure_rows})
    for benchmark in BENCHMARKS:
        lines.append(f"## {benchmark}")
        lines.append("")
        for method in methods:
            lines.append(f"### {method}")
            lines.append("")
            top_question_rows = [
                row
                for row in question_rows
                if row["benchmark"] == benchmark and row["method"] == method and row["num_queries"] >= 20
            ]
            top_question_rows = sorted(top_question_rows, key=lambda row: (row["failure_rate"], row["num_failures"]), reverse=True)[:8]
            lines.append("| slice | variant | num_queries | num_failures | accuracy | failure_rate |")
            lines.append("| --- | --- | --- | --- | --- | --- |")
            for row in top_question_rows:
                lines.append(
                    f"| {row['question_bucket']} | {row['variant']} | {row['num_queries']} | {row['num_failures']} | {row['accuracy']:.6f} | {row['failure_rate']:.6f} |"
                )
            lines.append("")
            top_failure_rows = [
                row
                for row in failure_rows
                if row["benchmark"] == benchmark and row["method"] == method and row["num_queries"] >= 20
            ]
            top_failure_rows = sorted(top_failure_rows, key=lambda row: (row["failure_rate"], row["num_failures"]), reverse=True)[:6]
            lines.append("| failure_bucket | variant | num_queries | num_failures | accuracy | failure_rate |")
            lines.append("| --- | --- | --- | --- | --- | --- |")
            for row in top_failure_rows:
                lines.append(
                    f"| {row['failure_bucket']} | {row['variant']} | {row['num_queries']} | {row['num_failures']} | {row['accuracy']:.6f} | {row['failure_rate']:.6f} |"
                )
            lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Analyze external end-to-end failure slices.")
    parser.add_argument("--pred-root", required=True, help="External end-to-end run root, for example outputs/external_runs_v2_full.")
    parser.add_argument("--retrieval-root", required=True, help="Retrieval diagnostics root, for example outputs/external_runs.")
    parser.add_argument("--output-dir", required=True, help="Directory for slice outputs.")
    args = parser.parse_args()

    pred_root = Path(args.pred_root)
    retrieval_root = Path(args.retrieval_root)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    joined_rows = build_joined_rows(pred_root, retrieval_root)
    question_rows = summarize_by(joined_rows, "question_bucket")
    failure_rows = summarize_by(joined_rows, "failure_bucket")

    write_csv(joined_rows, output_dir / "failure_rows.csv")
    write_csv(question_rows, output_dir / "failure_slices_by_question.csv")
    write_csv(failure_rows, output_dir / "failure_slices_by_bucket.csv")
    (output_dir / "failure_slices.md").write_text(render_markdown(question_rows, failure_rows), encoding="utf-8")

    print(f"wrote {output_dir / 'failure_rows.csv'}")
    print(f"wrote {output_dir / 'failure_slices_by_question.csv'}")
    print(f"wrote {output_dir / 'failure_slices_by_bucket.csv'}")
    print(f"wrote {output_dir / 'failure_slices.md'}")


if __name__ == "__main__":
    main()
