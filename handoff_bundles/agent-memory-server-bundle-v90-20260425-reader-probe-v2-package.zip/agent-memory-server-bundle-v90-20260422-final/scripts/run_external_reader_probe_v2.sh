#!/usr/bin/env bash

set -euo pipefail

PROJECT_ROOT="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
PYTHON_BIN="${PYTHON_BIN:-python}"
RETRIEVAL_ROOT="${RETRIEVAL_ROOT:-$PROJECT_ROOT/outputs/external_runs}"
PROBE_ROOT="${PROBE_ROOT:-$PROJECT_ROOT/outputs/external_reader_probe_v2}"

# Change this one line if both model folders live under the same parent directory.
OPEN_MODEL_HOME="${OPEN_MODEL_HOME:-/path/to/local_hf_models}"

QWEN_MODEL_PATH="${QWEN_MODEL_PATH:-$OPEN_MODEL_HOME/Qwen2.5-7B-Instruct}"
LLAMA_MODEL_PATH="${LLAMA_MODEL_PATH:-$OPEN_MODEL_HOME/Meta-Llama-3.1-8B-Instruct}"

READER_DEVICE="${READER_DEVICE:-cuda}"
READER_BATCH_SIZE="${READER_BATCH_SIZE:-2}"
READER_MAX_NEW_TOKENS="${READER_MAX_NEW_TOKENS:-24}"
READER_MAX_INPUT_TOKENS="${READER_MAX_INPUT_TOKENS:-6144}"
RETRIEVAL_VARIANT="${RETRIEVAL_VARIANT:-hybrid_bge_m3_rerank}"

export PYTHONPATH="${PROJECT_ROOT}/src:${PYTHONPATH:-}"

run_reader_probe() {
  local benchmark="$1"
  local method_name="$2"
  local model_path="$3"
  local summary_dir="$4"

  if [[ ! -d "$model_path" ]]; then
    echo "missing_reader_model method=$method_name model_path=$model_path" >&2
    return 1
  fi

  "$PYTHON_BIN" -m memory_collapse.cli run_external_reader_baseline \
    --benchmark "$benchmark" \
    --retrieval-variant "$RETRIEVAL_VARIANT" \
    --input-root "${RETRIEVAL_ROOT}/${benchmark}" \
    --method "$method_name" \
    --reader-model-path "$model_path" \
    --output-root "$PROBE_ROOT" \
    --summary-root "$summary_dir" \
    --reader-device "$READER_DEVICE" \
    --reader-batch-size "$READER_BATCH_SIZE" \
    --reader-max-new-tokens "$READER_MAX_NEW_TOKENS" \
    --reader-max-input-tokens "$READER_MAX_INPUT_TOKENS"
}

mkdir -p "$PROBE_ROOT"

run_reader_probe "longmemeval" "reader_qwen25_7b_instruct" "$QWEN_MODEL_PATH" "${PROBE_ROOT}/summary_longmemeval"
run_reader_probe "locomo" "reader_qwen25_7b_instruct" "$QWEN_MODEL_PATH" "${PROBE_ROOT}/summary_locomo"

run_reader_probe "longmemeval" "reader_llama31_8b_instruct" "$LLAMA_MODEL_PATH" "${PROBE_ROOT}/summary_longmemeval"
run_reader_probe "locomo" "reader_llama31_8b_instruct" "$LLAMA_MODEL_PATH" "${PROBE_ROOT}/summary_locomo"

"$PYTHON_BIN" "$PROJECT_ROOT/scripts/analyze_external_failures.py" \
  --pred-root "$PROBE_ROOT" \
  --retrieval-root "$RETRIEVAL_ROOT" \
  --output-dir "${PROBE_ROOT}/failure_slices"

echo "done"
echo "probe_root=$PROBE_ROOT"
