#!/usr/bin/env bash

set -euo pipefail

PROJECT_ROOT="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
PYTHON_BIN="${PYTHON_BIN:-python}"
RETRIEVAL_ROOT="${RETRIEVAL_ROOT:-$PROJECT_ROOT/outputs/external_runs}"
FREEZE_ROOT="${FREEZE_ROOT:-$PROJECT_ROOT/outputs/external_freeze_v90_aligned_r1}"

# Change this one line if both model folders live under the same parent directory.
OPEN_MODEL_HOME="${OPEN_MODEL_HOME:-/path/to/local_hf_models}"

QWEN_MODEL_PATH="${QWEN_MODEL_PATH:-$OPEN_MODEL_HOME/Qwen2.5-7B-Instruct}"
LLAMA_MODEL_PATH="${LLAMA_MODEL_PATH:-$OPEN_MODEL_HOME/Meta-Llama-3.1-8B-Instruct}"

READER_DEVICE="${READER_DEVICE:-cuda}"
READER_BATCH_SIZE="${READER_BATCH_SIZE:-2}"
READER_MAX_NEW_TOKENS="${READER_MAX_NEW_TOKENS:-24}"
READER_MAX_INPUT_TOKENS="${READER_MAX_INPUT_TOKENS:-6144}"

export PYTHONPATH="${PROJECT_ROOT}/src:${PYTHONPATH:-}"

run_reader_eval() {
  local benchmark="$1"
  local method_name="$2"
  local model_path="$3"
  local summary_dir="$4"

  if [[ ! -d "$model_path" ]]; then
    echo "skip_reader method=$method_name model_path=$model_path"
    return 0
  fi

  "$PYTHON_BIN" -m memory_collapse.cli run_external_reader_baseline \
    --benchmark "$benchmark" \
    --retrieval-variant tfidf \
    --retrieval-variant dense_e5 \
    --retrieval-variant dense_e5_rerank \
    --retrieval-variant hybrid_bge_m3 \
    --retrieval-variant hybrid_bge_m3_rerank \
    --input-root "${RETRIEVAL_ROOT}/${benchmark}" \
    --method "$method_name" \
    --reader-model-path "$model_path" \
    --output-root "$FREEZE_ROOT" \
    --summary-root "$summary_dir" \
    --reader-device "$READER_DEVICE" \
    --reader-batch-size "$READER_BATCH_SIZE" \
    --reader-max-new-tokens "$READER_MAX_NEW_TOKENS" \
    --reader-max-input-tokens "$READER_MAX_INPUT_TOKENS"
}

mkdir -p "$FREEZE_ROOT"

run_reader_eval "longmemeval" "reader_qwen25_7b_instruct" "$QWEN_MODEL_PATH" "${FREEZE_ROOT}/summary_longmemeval"
run_reader_eval "locomo" "reader_qwen25_7b_instruct" "$QWEN_MODEL_PATH" "${FREEZE_ROOT}/summary_locomo"

run_reader_eval "longmemeval" "reader_llama31_8b_instruct" "$LLAMA_MODEL_PATH" "${FREEZE_ROOT}/summary_longmemeval"
run_reader_eval "locomo" "reader_llama31_8b_instruct" "$LLAMA_MODEL_PATH" "${FREEZE_ROOT}/summary_locomo"

echo "done"
echo "freeze_root=$FREEZE_ROOT"
